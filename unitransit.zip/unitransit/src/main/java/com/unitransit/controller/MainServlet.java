package com.unitransit.controller;



import com.unitransit.config.DBConfig;

import jakarta.servlet.ServletException;

import jakarta.servlet.annotation.MultipartConfig;

import jakarta.servlet.annotation.WebServlet;

import jakarta.servlet.http.HttpServlet;

import jakarta.servlet.http.HttpServletRequest;

import jakarta.servlet.http.HttpServletResponse;

import jakarta.servlet.http.HttpSession;

import jakarta.servlet.http.Part;



import java.io.File;

import java.io.IOException;

import java.io.PrintWriter;

import java.io.InputStream;

import java.nio.file.Files;

import java.nio.file.StandardCopyOption;

import java.sql.*;

import java.util.ArrayList;

import java.util.HashMap;

import java.util.List;

import java.util.Map;



@WebServlet("/main")

@MultipartConfig(

    fileSizeThreshold = 1024 * 1024 * 2,  

    maxFileSize = 1024 * 1024 * 10,       

    maxRequestSize = 1024 * 1024 * 50     

)

public class MainServlet extends HttpServlet {



    private String uploadFile(Part part, String subFolder, HttpServletRequest request) throws IOException {

        if (part == null || part.getSize() == 0) {

            return "uploads/" + subFolder + "/default.png";

        }

        String submittedName = part.getSubmittedFileName();

        String fileExt = submittedName.substring(submittedName.lastIndexOf("."));

        String uniqueFileName = System.currentTimeMillis() + "_" + Math.round(Math.random() * 100000) + fileExt;

        

        String appPath = request.getServletContext().getRealPath("");

        String uploadDirPath = appPath + "/uploads/" + subFolder;

        

        File uploadDir = new File(uploadDirPath);

        if (!uploadDir.exists()) uploadDir.mkdirs();

        File targetFile = new File(uploadDir, uniqueFileName);

        try (InputStream input = part.getInputStream()) {

            Files.copy(input, targetFile.toPath(), StandardCopyOption.REPLACE_EXISTING);

        }

        return "uploads/" + subFolder + "/" + uniqueFileName;

    }



    private String getFormValue(HttpServletRequest request, String fieldName) throws IOException, ServletException {

        Part part = request.getPart(fieldName);

        if (part == null) return null;

        try (java.util.Scanner scanner = new java.util.Scanner(part.getInputStream(), "UTF-8")) {

            return scanner.hasNextLine() ? scanner.nextLine() : "";

        }

    }



    protected void doGet(HttpServletRequest request, HttpServletResponse response) 

            throws ServletException, IOException {

        String action = request.getParameter("action");

        HttpSession session = request.getSession(false);



        if ("logout".equals(action)) {

            if (session != null) session.invalidate();

            response.sendRedirect("login.jsp?msg=Successfully logged out.");

            return;

        }



        if (session == null || session.getAttribute("userId") == null) {

            response.sendRedirect("login.jsp");

            return;

        }



        int userId = (Integer) session.getAttribute("userId");

        String role = (String) session.getAttribute("role");

        try (Connection conn = DBConfig.getConnection()) {

            if ("getDashboardData".equals(action)) {

                response.setContentType("application/json");

                response.setCharacterEncoding("UTF-8");

                PrintWriter out = response.getWriter();

                

                if ("DRIVER".equalsIgnoreCase(role)) {

                    out.print(getDriverJsonData(conn, userId));

                } else if ("PASSENGER".equalsIgnoreCase(role)) {

                    out.print(getPassengerJsonData(conn, userId));

                }

                out.flush();

                return;

            }



            if ("profile".equals(action)) {

                if ("DRIVER".equalsIgnoreCase(role)) {

                    Map<String, Object> profile = new HashMap<>();

                    String sqlMe = "SELECT d.username, d.phone, d.bio, d.license_card_path, v.vehicle_type, v.model_info, v.plate_number " +

                                   "FROM drivers d LEFT JOIN vehicles v ON d.id = v.driver_id WHERE d.id = ?";

                    try (PreparedStatement ps = conn.prepareStatement(sqlMe)) {

                        ps.setInt(1, userId);

                        try (ResultSet rs = ps.executeQuery()) {

                            if (rs.next()) {

                                profile.put("username", rs.getString("username"));

                                profile.put("phone", rs.getString("phone") != null ? rs.getString("phone") : "");

                                profile.put("bio", rs.getString("bio") != null ? rs.getString("bio") : "");

                                profile.put("license_card", rs.getString("license_card_path") != null ? rs.getString("license_card_path") : "");

                                profile.put("vehicle_type", rs.getString("vehicle_type") != null ? rs.getString("vehicle_type") : "Standard Sedan");

                                profile.put("model_info", rs.getString("model_info") != null ? rs.getString("model_info") : "");

                                profile.put("plate_number", rs.getString("plate_number") != null ? rs.getString("plate_number") : "");

                            }

                        }

                    }

                    request.setAttribute("profile", profile);

                    request.getRequestDispatcher("driverProfile.jsp").forward(request, response);

                } else {

                    Map<String, Object> profile = new HashMap<>();

                    String sqlMe = "SELECT username, phone, bio, student_card_path FROM passengers WHERE id = ?";

                    try (PreparedStatement ps = conn.prepareStatement(sqlMe)) {

                        ps.setInt(1, userId);

                        try (ResultSet rs = ps.executeQuery()) {

                            if (rs.next()) {

                                profile.put("username", rs.getString("username"));

                                profile.put("phone", rs.getString("phone") != null ? rs.getString("phone") : "");

                                profile.put("bio", rs.getString("bio") != null ? rs.getString("bio") : "");

                                profile.put("student_card", rs.getString("student_card_path") != null ? rs.getString("student_card_path") : "");

                            }

                        }

                    }

                    request.setAttribute("profile", profile);

                    request.getRequestDispatcher("passengerProfile.jsp").forward(request, response);

                }

                return;

            }



            if ("verifyPassenger".equals(action)) {

                int id = Integer.parseInt(request.getParameter("id"));

                String status = request.getParameter("status"); 

                String sql = "UPDATE passengers SET account_status = ? WHERE id = ?";

                try (PreparedStatement stmt = conn.prepareStatement(sql)) {

                    stmt.setString(1, status);

                    stmt.setInt(2, id);

                    stmt.executeUpdate();

                }

                response.sendRedirect("main?msg=Passenger status updated.");

            } 

            else if ("verifyDriver".equals(action)) {

                int id = Integer.parseInt(request.getParameter("id"));

                String status = request.getParameter("status"); 

                String sql = "UPDATE drivers SET verification_status = ? WHERE id = ?";

                try (PreparedStatement stmt = conn.prepareStatement(sql)) {

                    stmt.setString(1, status);

                    stmt.setInt(2, id);

                    stmt.executeUpdate();

                }

                response.sendRedirect("main?msg=Driver status updated.");

            }

            else {

                if ("DRIVER".equalsIgnoreCase(role)) {

                    setupDriverDashboardData(request, conn, userId);

                    request.getRequestDispatcher("driver.jsp").forward(request, response);

                } else if ("ADMIN".equalsIgnoreCase(role)) {

                    List<Map<String, Object>> registeredPassengers = new ArrayList<>();

                    List<Map<String, Object>> registeredDrivers = new ArrayList<>();



                    String pSql = "SELECT id, username, phone, bio, student_card_path, account_status FROM passengers WHERE account_status != 'PENDING'";

                    try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(pSql)) {

                        while (rs.next()) {

                            Map<String, Object> p = new HashMap<>();

                            p.put("id", rs.getInt("id"));

                            p.put("username", rs.getString("username"));

                            p.put("phone", rs.getString("phone"));

                            p.put("bio", rs.getString("bio") != null ? rs.getString("bio") : "No bio configured.");

                            p.put("student_card", rs.getString("student_card_path"));

                            p.put("status", rs.getString("account_status"));

                            registeredPassengers.add(p);

                        }

                    }



                    String dSql = "SELECT d.id, d.username, d.phone, d.license_card_path, d.verification_status, v.vehicle_type, v.model_info, v.plate_number " +

                                  "FROM drivers d LEFT JOIN vehicles v ON d.id = v.driver_id WHERE d.verification_status != 'PENDING'";

                    try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(dSql)) {

                        while (rs.next()) {

                            Map<String, Object> d = new HashMap<>();

                            d.put("id", rs.getInt("id"));

                            d.put("username", rs.getString("username"));

                            d.put("phone", rs.getString("phone"));

                            d.put("license_card", rs.getString("license_card_path"));

                            d.put("status", rs.getString("verification_status"));

                            d.put("vehicle_type", rs.getString("vehicle_type"));

                            d.put("model_info", rs.getString("model_info"));

                            d.put("plate_number", rs.getString("plate_number"));

                            registeredDrivers.add(d);

                        }

                    }



                    request.setAttribute("registeredPassengers", registeredPassengers);

                    request.setAttribute("registeredDrivers", registeredDrivers);

                    request.getRequestDispatcher("admin.jsp").forward(request, response);

                } else {

                    setupPassengerDashboardData(request, conn, userId);

                    request.getRequestDispatcher("passenger.jsp").forward(request, response);

                }

            }

        } catch (SQLException e) {

            throw new ServletException(e);

        }

    }



    protected void doPost(HttpServletRequest request, HttpServletResponse response) 

            throws ServletException, IOException {

        String action = request.getParameter("action");

        HttpSession session = request.getSession(false);



        if ("signup".equals(action)) {

            handleSignup(request, response);

            return;

        }



        if ("login".equals(action)) {

            handleLogin(request, response);

            return;

        }



        if (session == null || session.getAttribute("userId") == null) {

            response.sendRedirect("login.jsp");

            return;

        }



        int userId = (Integer) session.getAttribute("userId");

        try (Connection conn = DBConfig.getConnection()) {

               

            if ("createRequest".equals(action)) {

                String pickup = request.getParameter("pickup");

                String dropoff = request.getParameter("dropoff");

                String vehicleType = request.getParameter("vehicle_type");

                

                if (vehicleType == null || vehicleType.trim().isEmpty()) {

                    vehicleType = "Standard Sedan";

                }



                if (pickup == null || pickup.trim().isEmpty()) {

                    pickup = "Unknown";

                } else {

                    pickup = pickup.trim();

                }

                

                if (dropoff == null || dropoff.trim().isEmpty()) {

                    dropoff = "Unknown";

                } else {

                    dropoff = dropoff.trim();

                }



                int routeId = getOrCreateRoute(conn, pickup, dropoff);

                String sqlBooking = "INSERT INTO bookings (passenger_id, route_id, vehicle_type, status) VALUES (?, ?, ?, 'PENDING')";

                try (PreparedStatement stmt = conn.prepareStatement(sqlBooking)) {

                    stmt.setInt(1, userId);

                    stmt.setInt(2, routeId);

                    stmt.setString(3, vehicleType);

                    stmt.executeUpdate();

                }

                response.sendRedirect("main");

            }



            else if ("acceptRequest".equals(action)) {

                int bookingId = Integer.parseInt(request.getParameter("requestId"));

                double fare = Double.parseDouble(request.getParameter("fare"));



                String sqlOffer = "UPDATE bookings SET driver_id = ?, quoted_fare = ?, status = 'OFFERED' WHERE id = ?";

                try (PreparedStatement stmt = conn.prepareStatement(sqlOffer)) {

                    stmt.setInt(1, userId);

                    stmt.setDouble(2, fare);

                    stmt.setInt(3, bookingId);

                    stmt.executeUpdate();

                }

                response.sendRedirect("main");

            }



            else if ("acceptBid".equals(action)) {

                String reqIdStr = request.getParameter("requestId");

                if (reqIdStr != null) {

                    int bookingId = Integer.parseInt(reqIdStr);

                    String sql = "UPDATE bookings SET status = 'ACCEPTED' WHERE id = ?";

                    try (PreparedStatement stmt = conn.prepareStatement(sql)) {

                        stmt.setInt(1, bookingId);

                        stmt.executeUpdate();

                    }

                }

                response.sendRedirect("main?msg=Offer+Accepted!+Driver+is+en-route.");

            }



            else if ("rejectBid".equals(action)) {

                String reqIdStr = request.getParameter("requestId");

                if (reqIdStr != null) {

                    int bookingId = Integer.parseInt(reqIdStr);

                    String sql = "UPDATE bookings SET driver_id = NULL, quoted_fare = NULL, status = 'PENDING' WHERE id = ?";

                    try (PreparedStatement stmt = conn.prepareStatement(sql)) {

                        stmt.setInt(1, bookingId);

                        stmt.executeUpdate();

                    }

                }

                response.sendRedirect("main?msg=Offer+declined.");

            }



            else if ("settleRide".equals(action)) {

                int bookingId = Integer.parseInt(request.getParameter("requestId"));

                conn.setAutoCommit(false); 

                try {

                    String fetchSql = "SELECT b.quoted_fare, b.vehicle_type, p.username AS p_name, d.username AS d_name, r.pickup_location, r.dropoff_location " +

                                      "FROM bookings b " +

                                      "LEFT JOIN passengers p ON b.passenger_id = p.id " +

                                      "LEFT JOIN drivers d ON b.driver_id = d.id " +

                                      "LEFT JOIN routes r ON b.route_id = r.id WHERE b.id = ?";

                    try (PreparedStatement fetchStmt = conn.prepareStatement(fetchSql)) {

                        fetchStmt.setInt(1, bookingId);

                        try (ResultSet rs = fetchStmt.executeQuery()) {

                            if (rs.next()) {

                                String passengerName = rs.getString("p_name") != null ? rs.getString("p_name") : "Passenger";

                                String driverName = rs.getString("d_name") != null ? rs.getString("d_name") : "Driver";

                                String pickup = rs.getString("pickup_location") != null ? rs.getString("pickup_location") : "Unknown";

                                String dropoff = rs.getString("dropoff_location") != null ? rs.getString("dropoff_location") : "Unknown";

                                String vehicleType = rs.getString("vehicle_type") != null ? rs.getString("vehicle_type") : "Standard Sedan";

                                java.math.BigDecimal fare = rs.getBigDecimal("quoted_fare") != null ? rs.getBigDecimal("quoted_fare") : java.math.BigDecimal.ZERO;

                                

                                String logSql = "INSERT INTO ride_history (booking_id, passenger_name, driver_name, pickup_loc, dropoff_loc, vehicle_type, final_fare) VALUES (?, ?, ?, ?, ?, ?, ?)";

                                try (PreparedStatement logStmt = conn.prepareStatement(logSql)) {

                                    logStmt.setInt(1, bookingId);

                                    logStmt.setString(2, passengerName);

                                    logStmt.setString(3, driverName);

                                    logStmt.setString(4, pickup);

                                    logStmt.setString(5, dropoff);

                                    logStmt.setString(6, vehicleType);

                                    logStmt.setBigDecimal(7, fare);

                                    logStmt.executeUpdate();

                                }



                                String updateSql = "UPDATE bookings SET status = 'COMPLETED' WHERE id = ?";

                                try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {

                                    updateStmt.setInt(1, bookingId);

                                    updateStmt.executeUpdate();

                                }

                            }

                        }

                    }

                    conn.commit();

                    response.sendRedirect("main");

                } catch (Exception e) {

                    conn.rollback();

                    throw new ServletException("Settlement loop crash.", e);

                } finally {

                    conn.setAutoCommit(true);

                }

            }

            

            else if ("updateProfile".equals(action)) {

                String username = request.getParameter("username");

                String phone = request.getParameter("phone");

                String bio = request.getParameter("bio");

                String role = (String) session.getAttribute("role");

                if (username == null || username.trim().isEmpty()) {

                    response.sendRedirect("main?error=invalid_username");

                    return;

                }



                if ("DRIVER".equalsIgnoreCase(role)) {

                    String vehicleInfo = request.getParameter("vehicle_info");

                    Part filePart = request.getPart("licenseFile");

                    String imgPath = null;

                    if (filePart != null && filePart.getSize() > 0) {

                        imgPath = uploadFile(filePart, "licenses", request);

                    }



                    StringBuilder sqlD = new StringBuilder("UPDATE drivers SET username = ?, phone = ?, bio = ?");

                    if (imgPath != null) sqlD.append(", license_card_path = ?");

                    sqlD.append(" WHERE id = ?");

                    try (PreparedStatement stmt = conn.prepareStatement(sqlD.toString())) {

                        stmt.setString(1, username);

                        stmt.setString(2, phone);

                        stmt.setString(3, bio);

                        if (imgPath != null) {

                            stmt.setString(4, imgPath);

                            stmt.setInt(5, userId);

                        } else {

                            stmt.setInt(4, userId);

                        }

                        stmt.executeUpdate();

                    }

                    String sqlV = "UPDATE vehicles SET model_info = ? WHERE driver_id = ?";

                    try (PreparedStatement stmt = conn.prepareStatement(sqlV)) {

                        stmt.setString(1, vehicleInfo);

                        stmt.setInt(2, userId);

                        stmt.executeUpdate();

                    }

                } else {

                    Part filePart = request.getPart("studentCardFile");

                    String imgPath = null;

                    if (filePart != null && filePart.getSize() > 0) {

                        imgPath = uploadFile(filePart, "cards", request);

                    }



                    StringBuilder sqlP = new StringBuilder("UPDATE passengers SET username = ?, phone = ?, bio = ?");

                    if (imgPath != null) sqlP.append(", student_card_path = ?");

                    sqlP.append(" WHERE id = ?");

                    try (PreparedStatement stmt = conn.prepareStatement(sqlP.toString())) {

                        stmt.setString(1, username);

                        stmt.setString(2, phone);

                        stmt.setString(3, bio);

                        if (imgPath != null) {

                            stmt.setString(4, imgPath);

                            stmt.setInt(5, userId);

                        } else {

                            stmt.setInt(4, userId);

                        }

                        stmt.executeUpdate();

                    }

                }

                

                session.setAttribute("username", username);

                response.sendRedirect("main?msg=Configurations saved.");

            }

        } catch (SQLException e) {

            throw new ServletException(e);

        }

    }
    
private void handleLogin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String user = request.getParameter("username");

        String pass = request.getParameter("password");

        String selectedRole = request.getParameter("role");

        String sql = "";

        if ("PASSENGER".equals(selectedRole)) {

            sql = "SELECT id, username, account_status AS status_flag FROM passengers WHERE username = ? AND password = ?";

        } else if ("DRIVER".equals(selectedRole)) {

            sql = "SELECT id, username, verification_status AS status_flag FROM drivers WHERE username = ? AND password = ?";

        } else if ("ADMIN".equals(selectedRole)) {

            sql = "SELECT id, username, 'APPROVED' AS status_flag FROM admins WHERE username = ? AND password = ?";

        }



        try (Connection conn = DBConfig.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, user);

            stmt.setString(2, pass);

            try (ResultSet rs = stmt.executeQuery()) {

                if (rs.next()) {

                    String statusFlag = rs.getString("status_flag");

                    if ("APPROVED".equals(statusFlag)) {

                        HttpSession session = request.getSession(true);

                        session.setAttribute("userId", rs.getInt("id"));

                        session.setAttribute("username", rs.getString("username"));

                        session.setAttribute("role", selectedRole);

                        response.sendRedirect("main"); 

                    } 

                    else if ("PENDING".equals(statusFlag)) response.sendRedirect("login.jsp?error=pending");

                    else if ("REJECTED".equals(statusFlag)) response.sendRedirect("login.jsp?error=rejected");

                } else {

                    response.sendRedirect("login.jsp?error=invalid");

                }

            }

        } catch (SQLException e) {

            throw new ServletException(e);

        }

    }



    private void handleSignup(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        try (Connection conn = DBConfig.getConnection()) {

            String role = getFormValue(request, "role");

            String user = getFormValue(request, "username");

            String pass = getFormValue(request, "password");

            String phone = getFormValue(request, "phone");

            if ("PASSENGER".equals(role)) {

                Part filePart = request.getPart("studentCardFile");

                String databaseSavedPath = uploadFile(filePart, "cards", request);

                String sqlPassenger = "INSERT INTO passengers (username, password, phone, student_card_path, account_status) VALUES (?, ?, ?, ?, 'PENDING')";

                try (PreparedStatement stmt = conn.prepareStatement(sqlPassenger)) {

                    stmt.setString(1, user);

                    stmt.setString(2, pass);

                    stmt.setString(3, phone);

                    stmt.setString(4, databaseSavedPath);

                    stmt.executeUpdate();

                } catch (SQLIntegrityConstraintViolationException e) {

                    response.sendRedirect("signup.jsp?error=duplicate&user=" + user);

                    return;

                }

                response.sendRedirect("login.jsp?msg=Passenger profile submitted.");

            } else if ("DRIVER".equals(role)) {

                Part filePart = request.getPart("licenseFile");

                String databaseSavedPath = uploadFile(filePart, "licenses", request);

                String vehicleType = getFormValue(request, "vehicleType");

                String modelInfo = getFormValue(request, "modelInfo");

                String plateNumber = getFormValue(request, "plateNumber");



                conn.setAutoCommit(false);

                try {

                    String sqlDriver = "INSERT INTO drivers (username, password, phone, license_card_path, verification_status) VALUES (?, ?, ?, ?, 'PENDING')";

                    int newDriverId = 0;

                    try (PreparedStatement stmt = conn.prepareStatement(sqlDriver, Statement.RETURN_GENERATED_KEYS)) {

                        stmt.setString(1, user);

                        stmt.setString(2, pass);

                        stmt.setString(3, phone);

                        stmt.setString(4, databaseSavedPath);

                        stmt.executeUpdate();

                        try (ResultSet rs = stmt.getGeneratedKeys()) {

                            if (rs.next()) newDriverId = rs.getInt(1);

                        }

                    }

                    String sqlVehicle = "INSERT INTO vehicles (driver_id, vehicle_type, model_info, plate_number) VALUES (?, ?, ?, ?)";

                    try (PreparedStatement stmt = conn.prepareStatement(sqlVehicle)) {

                        stmt.setInt(1, newDriverId);

                        stmt.setString(2, vehicleType);

                        stmt.setString(3, modelInfo);

                        stmt.setString(4, plateNumber);

                        stmt.executeUpdate();

                    }

                    conn.commit();

                    response.sendRedirect("login.jsp?msg=Driver application received.");

                } catch (SQLIntegrityConstraintViolationException ex) {

                    conn.rollback();

                    response.sendRedirect("signup.jsp?error=duplicate&user=" + user);

                    return;

                } catch (SQLException ex) {

                    conn.rollback();

                    throw new ServletException("Signup failed.", ex);

                } finally {

                    conn.setAutoCommit(true);

                }

            }

        } catch (SQLException e) {

            throw new ServletException(e);

        }

    }



    private void setupDriverDashboardData(HttpServletRequest request, Connection conn, int driverId) throws SQLException {

        request.setAttribute("market", getMarketList(conn));

        request.setAttribute("activeJob", getDriverActiveJob(conn, driverId));

        request.setAttribute("history", getDriverHistory(conn, driverId));

        

        Map<String, Object> me = new HashMap<>();

        String sqlMe = "SELECT d.username, d.phone, d.bio, d.license_card_path, v.model_info AS vehicle FROM drivers d LEFT JOIN vehicles v ON d.id = v.driver_id WHERE d.id = ?";

        try (PreparedStatement ps = conn.prepareStatement(sqlMe)) {

            ps.setInt(1, driverId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    me.put("username", rs.getString("username"));

                    me.put("phone", rs.getString("phone") != null ? rs.getString("phone") : "");

                    me.put("bio", rs.getString("bio") != null ? rs.getString("bio") : "");

                    me.put("vehicle", rs.getString("vehicle") != null ? rs.getString("vehicle") : "");

                    me.put("photo", rs.getString("license_card_path") != null ? rs.getString("license_card_path") : "uploads/licenses/default.png");

                }

            }

        }

        request.setAttribute("me", me);

    }



    private void setupPassengerDashboardData(HttpServletRequest request, Connection conn, int passengerId) throws SQLException {

        request.setAttribute("activeRequest", getPassengerActiveRequest(conn, passengerId));

        request.setAttribute("history", getPassengerHistory(conn, passengerId));

        

        Map<String, Object> me = new HashMap<>();

        String sqlMe = "SELECT username, phone, bio, student_card_path FROM passengers WHERE id = ?";

        try (PreparedStatement ps = conn.prepareStatement(sqlMe)) {

            ps.setInt(1, passengerId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    me.put("username", rs.getString("username"));

                    me.put("phone", rs.getString("phone") != null ? rs.getString("phone") : "");

                    me.put("bio", rs.getString("bio") != null ? rs.getString("bio") : "");

                    me.put("photo", rs.getString("student_card_path") != null ? rs.getString("student_card_path") : "uploads/cards/default.png");

                }

            }

        }

        request.setAttribute("me", me);

    }



    private String getDriverJsonData(Connection conn, int driverId) throws SQLException {

        Map<String, Object> job = getDriverActiveJob(conn, driverId);

        List<Map<String, Object>> market = getMarketList(conn);

        List<Map<String, Object>> history = getDriverHistory(conn, driverId);



        StringBuilder json = new StringBuilder("{");

        json.append("\"hasActiveJob\":").append(job != null).append(",");

        if (job != null) {

            json.append("\"job\":{")

                .append("\"id\":").append(job.get("id")).append(",")

                .append("\"status\":\"").append(job.get("status")).append("\",")

                .append("\"fare\":").append(job.get("fare")).append(",")

                .append("\"pickup\":\"").append(job.get("pickup")).append("\",")

                .append("\"dropoff\":\"").append(job.get("dropoff")).append("\"")

                .append("},");

        }

        

        json.append("\"market\":[");

        for (int i = 0; i < market.size(); i++) {

            Map<String, Object> m = market.get(i);

            json.append("{\"id\":").append(m.get("id"))

                .append(",\"pickup\":\"").append(m.get("pickup")).append("\"")

                .append(",\"dropoff\":\"").append(m.get("dropoff")).append("\"}");

            if (i < market.size() - 1) json.append(",");

        }

        json.append("],");



        json.append("\"history\":[");

        for (int i = 0; i < history.size(); i++) {

            Map<String, Object> h = history.get(i);

            json.append("{\"id\":").append(h.get("id"))

                .append(",\"pickup\":\"").append(h.get("pickup")).append("\"")

                .append(",\"dropoff\":\"").append(h.get("dropoff")).append("\"")

                .append(",\"vehicle_type\":\"").append(h.get("vehicle_type")).append("\"")

                .append(",\"fare\":").append(h.get("fare")).append("}");

            if (i < history.size() - 1) json.append(",");

        }

        json.append("]}");

        return json.toString();

    }



    private String getPassengerJsonData(Connection conn, int passengerId) throws SQLException {

        Map<String, Object> req = getPassengerActiveRequest(conn, passengerId);

        List<Map<String, Object>> history = getPassengerHistory(conn, passengerId);



        StringBuilder json = new StringBuilder("{");

        json.append("\"hasActiveRequest\":").append(req != null).append(",");

        if (req != null) {

            json.append("\"request\":{")

                .append("\"id\":").append(req.get("id")).append(",")

                .append("\"status\":\"").append(req.get("status")).append("\",")

                .append("\"fare\":").append(req.get("fare")).append(",")

                .append("\"pickup\":\"").append(req.get("pickup")).append("\",")

                .append("\"dropoff\":\"").append(req.get("dropoff")).append("\"")

                .append("},");

        }



        json.append("\"history\":[");

        for (int i = 0; i < history.size(); i++) {

            Map<String, Object> h = history.get(i);

            json.append("{\"id\":").append(h.get("id"))

                .append(",\"pickup\":\"").append(h.get("pickup")).append("\"")

                .append(",\"dropoff\":\"").append(h.get("dropoff")).append("\"")

                .append(",\"vehicle_type\":\"").append(h.get("vehicle_type")).append("\"")

                .append(",\"fare\":").append(h.get("fare")).append("}");

            if (i < history.size() - 1) json.append(",");

        }

        json.append("]}");

        return json.toString();

    }



    private List<Map<String, Object>> getMarketList(Connection conn) throws SQLException {

        List<Map<String, Object>> market = new ArrayList<>();

        String sqlMarket = "SELECT b.id, r.pickup_location AS pickup, r.dropoff_location AS dropoff FROM bookings b JOIN routes r ON b.route_id = r.id WHERE b.status = 'PENDING'";

        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sqlMarket)) {

            while (rs.next()) {

                Map<String, Object> req = new HashMap<>();

                req.put("id", rs.getInt("id"));

                req.put("pickup", rs.getString("pickup"));

                req.put("dropoff", rs.getString("dropoff"));

                market.add(req);

            }

        }

        return market;

    }



    private Map<String, Object> getDriverActiveJob(Connection conn, int driverId) throws SQLException {

        String sqlJob = "SELECT b.id, b.status, b.quoted_fare AS fare, r.pickup_location AS pickup, r.dropoff_location AS dropoff " +

                        "FROM bookings b JOIN routes r ON b.route_id = r.id " +

                        "WHERE b.driver_id = ? " +

                        "AND b.status IN ('OFFERED', 'ACCEPTED')";

        try (PreparedStatement ps = conn.prepareStatement(sqlJob)) {

            ps.setInt(1, driverId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    Map<String, Object> activeJob = new HashMap<>();

                    activeJob.put("id", rs.getInt("id"));

                    activeJob.put("status", rs.getString("status"));

                    activeJob.put("fare", rs.getDouble("fare"));

                    activeJob.put("pickup", rs.getString("pickup"));

                    activeJob.put("dropoff", rs.getString("dropoff"));

                    return activeJob;

                }

            }

        }

        return null;

    }



    private List<Map<String, Object>> getDriverHistory(Connection conn, int driverId) throws SQLException {

        List<Map<String, Object>> history = new ArrayList<>();

        String sqlHist = "SELECT id, pickup_loc AS pickup, dropoff_loc AS dropoff, vehicle_type, final_fare AS fare FROM ride_history WHERE driver_name = (SELECT username FROM drivers WHERE id = ?)";

        try (PreparedStatement ps = conn.prepareStatement(sqlHist)) {

            ps.setInt(1, driverId);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {

                    Map<String, Object> h = new HashMap<>();

                    h.put("id", rs.getInt("id"));

                    h.put("pickup", rs.getString("pickup"));

                    h.put("dropoff", rs.getString("dropoff"));

                    

                    String vType = rs.getString("vehicle_type");

                    if (vType != null && vType.contains("Core (4 Seats)")) {

                        vType = "Standard Sedan";

                    }

                    h.put("vehicle_type", vType != null ? vType : "Standard Sedan");

                    

                    h.put("fare", rs.getDouble("fare"));

                    history.add(h);

                }

            }

        }

        return history;

    }



    private Map<String, Object> getPassengerActiveRequest(Connection conn, int passengerId) throws SQLException {

        String sqlReq = "SELECT b.id, b.status, b.quoted_fare AS fare, r.pickup_location AS pickup, r.dropoff_location AS dropoff " +

                        "FROM bookings b JOIN routes r ON b.route_id = r.id " +

                        "WHERE b.passenger_id = ? " +

                        "AND b.status IN ('PENDING', 'OFFERED', 'ACCEPTED')";

        try (PreparedStatement ps = conn.prepareStatement(sqlReq)) {

            ps.setInt(1, passengerId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    Map<String, Object> activeRequest = new HashMap<>();

                    activeRequest.put("id", rs.getInt("id"));

                    activeRequest.put("status", rs.getString("status"));

                    activeRequest.put("fare", rs.getDouble("fare"));

                    activeRequest.put("pickup", rs.getString("pickup"));

                    activeRequest.put("dropoff", rs.getString("dropoff"));

                    return activeRequest;

                }

            }

        }

        return null;

    }



    private List<Map<String, Object>> getPassengerHistory(Connection conn, int passengerId) throws SQLException {

        List<Map<String, Object>> history = new ArrayList<>();

        String sqlHist = "SELECT id, pickup_loc AS pickup, dropoff_loc AS dropoff, vehicle_type, final_fare AS fare FROM ride_history WHERE passenger_name = (SELECT username FROM passengers WHERE id = ?)";

        try (PreparedStatement ps = conn.prepareStatement(sqlHist)) {

            ps.setInt(1, passengerId);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {

                    Map<String, Object> h = new HashMap<>();

                    h.put("id", rs.getInt("id"));

                    h.put("pickup", rs.getString("pickup"));

                    h.put("dropoff", rs.getString("dropoff"));

                    

                    String vType = rs.getString("vehicle_type");

                    if (vType != null && vType.contains("Core (4 Seats)")) {

                        vType = "Standard Sedan";

                    }

                    h.put("vehicle_type", vType != null ? vType : "Standard Sedan");

                    

                    h.put("fare", rs.getDouble("fare"));

                    history.add(h);

                }

            }

        }

        return history;

    }



    private int getOrCreateRoute(Connection conn, String pickup, String dropoff) throws SQLException {

        String checkSql = "SELECT id FROM routes WHERE pickup_location = ? AND dropoff_location = ?";

        try (PreparedStatement stmt = conn.prepareStatement(checkSql)) {

            stmt.setString(1, pickup);

            stmt.setString(2, dropoff);

            try (ResultSet rs = stmt.executeQuery()) {

                if (rs.next()) {

                    return rs.getInt("id");

                }

            }

        }

        String insertSql = "INSERT INTO routes (pickup_location, dropoff_location) VALUES (?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, pickup);

            stmt.setString(2, dropoff);

            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {

                if (rs.next()) {

                    return rs.getInt(1);

                }

            }

        }

        throw new SQLException("Failed to trace or construct route entries.");

    }

}