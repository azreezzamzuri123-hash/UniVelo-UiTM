<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>UniTransit - Operational Authentication Gateway</title>
    <style>
        :root {
            --bg-color: #0f172a;
            --card-bg: #1e293b;
            --accent-blue: #38bdf8;
            --accent-green: #34d399;
            --accent-rose: #f87171;
            --text-main: #f8fafc;
            --text-muted: #94a3b8;
            --border-color: #334155;
        }

        body {
            background-color: var(--bg-color);
            color: var(--text-main);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .login-container {
            background-color: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 40px;
            width: 100%;
            max-width: 480px;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.3);
            margin: 20px;
        }

        h2 {
            margin-top: 0;
            font-size: 26px;
            font-weight: 600;
            color: var(--text-main);
            text-align: center;
            letter-spacing: -0.5px;
            margin-bottom: 8px;
        }

        p.subtitle {
            text-align: center;
            color: var(--text-muted);
            margin-top: 0;
            margin-bottom: 30px;
            font-size: 14px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-size: 14px;
            font-weight: 500;
            color: var(--text-main);
        }

        input[type="text"],
        input[type="password"],
        select {
            width: 100%;
            padding: 12px;
            background-color: var(--bg-color);
            border: 1px solid var(--border-color);
            border-radius: 6px;
            color: var(--text-main);
            font-size: 15px;
            box-sizing: border-box;
            transition: border-color 0.2s;
        }

        input:focus, select:focus {
            outline: none;
            border-color: var(--accent-blue);
        }

        .btn-submit {
            width: 100%;
            padding: 14px;
            background-color: var(--accent-green);
            color: #0f172a;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.2s, transform 0.1s;
            margin-top: 10px;
        }

        .btn-submit:hover {
            background-color: #6ee7b7;
        }

        .btn-submit:active {
            transform: scale(0.98);
        }

        .footer-links {
            text-align: center;
            margin-top: 25px;
            font-size: 14px;
            color: var(--text-muted);
        }

        .footer-links a {
            color: var(--accent-blue);
            text-decoration: none;
        }

        .footer-links a:hover {
            text-decoration: underline;
        }

        /* Status Notification Banners */
        .alert {
            padding: 14px;
            border-radius: 6px;
            margin-bottom: 25px;
            font-size: 14px;
            line-height: 1.5;
        }

        .alert-danger {
            background-color: rgba(239, 68, 68, 0.15);
            color: var(--accent-rose);
            border: 1px solid rgba(239, 68, 68, 0.3);
        }

        .alert-success {
            background-color: rgba(52, 211, 153, 0.15);
            color: var(--accent-green);
            border: 1px solid rgba(52, 211, 153, 0.3);
        }
    </style>
</head>
<body>

    <div class="login-container">
        <h2>UniTransit Gateway</h2>
        <p class="subtitle">Verify security clearance parameters for node access</p>

        <%-- Error Alert Messages --%>
        <% if (request.getParameter("error") != null) { %>
            <div class="alert alert-danger">
                <strong>Access Halted:</strong> 
                <% if ("invalid".equals(request.getParameter("error"))) { %>
                    Invalid credential identity match.
                <% } else if ("pending".equals(request.getParameter("error"))) { %>
                    Your access application manifest is currently pending network validation review.
                <% } else if ("rejected".equals(request.getParameter("error"))) { %>
                    Administrative check on this profile handle failed.
                <% } else { %>
                    An unexpected system error occurred during authentication routing.
                <% } %>
            </div>
        <% } %>

        <%-- Success Alert Messages --%>
        <% if (request.getParameter("msg") != null) { %>
            <div class="alert alert-success">
                <%= request.getParameter("msg") %>
            </div>
        <% } %>

        <form action="main" method="POST">
            <input type="hidden" name="action" value="login" />

            <div class="form-group">
                <label for="username">Username Identity</label>
                <input type="text" id="username" name="username" placeholder="Enter system login handle" required />
            </div>

            <div class="form-group">
                <label for="password">Account Password</label>
                <input type="password" id="password" name="password" placeholder="••••••••" required />
            </div>

            <div class="form-group">
                <label for="role">System Entrance Context Role</label>
                <select id="role" name="role" required>
                    <option value="PASSENGER">Passenger Hub Terminal</option>
                    <option value="DRIVER">Driver Operations Terminal</option>
                    <option value="ADMIN">Administrative Gateway</option>
                </select>
            </div>

            <button type="submit" class="btn-submit">Verify Security Clearance</button>
        </form>

        <div class="footer-links">
            New to the campus network grid? <a href="signup.jsp">Create an account here</a>
        </div>
    </div>

</body>
</html>