<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.Map" %>
<%
    Map<String, Object> profile = (Map<String, Object>) request.getAttribute("profile");
    String username = (profile != null && profile.get("username") != null) ? (String) profile.get("username") : "";
    String phone = (profile != null && profile.get("phone") != null) ? (String) profile.get("phone") : "";
    String bio = (profile != null && profile.get("bio") != null) ? (String) profile.get("bio") : "";
    String vehicleInfo = (profile != null && profile.get("model_info") != null) ? (String) profile.get("model_info") : "";
    String licenseCard = (profile != null && profile.get("license_card") != null) ? (String) profile.get("license_card") : "";
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>UniTransit | Edit Driver Profile</title>
    <style>
        :root {
            --bg-main: #060913;
            --panel-bg: #0d1222;
            --card-bg: #121a32;
            --primary-glow: #a855f7;
            --secondary-glow: #e879f9;
            --accent-emerald: #10b981;
            --accent-rose: #f43f5e;
            --text-heading: #f8fafc;
            --text-body: #cbd5e1;
            --text-muted: #64748b;
            --border-glow: #1e293b;
        }

        body { 
            font-family: 'Inter', system-ui, -apple-system, sans-serif; 
            background-color: var(--bg-main); 
            margin: 0; 
            display: flex; 
            color: var(--text-body); 
            letter-spacing: -0.01em;
        }

        .sidebar { 
            width: 280px; 
            background-color: var(--panel-bg); 
            height: 100vh; 
            padding: 30px 24px; 
            box-sizing: border-box; 
            border-right: 1px solid var(--border-glow); 
            position: fixed; 
        }

        .sidebar h1 { 
            font-size: 1.6rem;
            font-weight: 800;
            background: linear-gradient(to right, var(--primary-glow), var(--secondary-glow));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin: 0 0 5px 0; 
        }

        .sidebar p { color: var(--text-muted); margin: 5px 0 25px 0; font-size: 14px; font-weight: 500; }
        
        /* --- Sidebar Navigation Links --- */
        .sidebar a { 
            display: block; 
            color: #94a3b8; 
            text-decoration: none; 
            padding: 14px 20px; 
            font-weight: 600; 
            font-size: 15px;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid rgba(255, 255, 255, 0.04);
            margin-bottom: 12px;
            box-sizing: border-box;
            transition: all 0.2s ease;
        }
        
        .sidebar a:hover { 
            color: white; 
            background: rgba(168, 85, 247, 0.16);
            border-color: rgba(168, 85, 247, 0.4);
            box-shadow: 0 0 20px rgba(168, 85, 247, 0.4);
        }

        /* Unique layout danger link rule for Logout link */
        .sidebar a[href*="logout"] {
            color: var(--accent-rose);
            background: rgba(244, 63, 94, 0.03);
            border-color: rgba(244, 63, 94, 0.1);
            margin-top: 20px;
        }
        .sidebar a[href*="logout"]:hover {
            background: rgba(244, 63, 94, 0.15);
            border-color: rgba(244, 63, 94, 0.4);
            box-shadow: 0 0 20px rgba(244, 63, 94, 0.4);
            color: #ff4d6d;
        }

        .main-content { flex: 1; padding: 40px; margin-left: 280px; box-sizing: border-box; background-color: var(--bg-main); }
        
        .card { 
            background: var(--card-bg); 
            padding: 30px; 
            border-radius: 16px; 
            border: 1px solid var(--border-glow); 
            margin-bottom: 30px; 
            box-shadow: 0 20px 40px -15px rgba(0,0,0,0.5);
            position: relative;
            overflow: hidden;
            width: 100%;
            box-sizing: border-box;
        }

        .card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; height: 1px;
            background: linear-gradient(90deg, transparent, rgba(139, 92, 246, 0.2), transparent);
        }

        .card h3 { margin-top: 0; color: var(--text-heading); font-size: 1.25rem; font-weight: 700; margin-bottom: 25px; }
        
        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: var(--text-heading);
            font-size: 14px;
            font-weight: 600;
        }

        .input-field { 
            width: 100%; 
            padding: 14px; 
            background: rgba(6, 9, 19, 0.6); 
            border: 1px solid var(--border-glow); 
            border-radius: 8px; 
            color: white; 
            font-size: 15px; 
            box-sizing: border-box; 
            transition: border-color 0.2s;
            font-family: inherit;
        }
        .input-field:focus { border-color: var(--primary-glow); outline: none; }
        
        textarea.input-field {
            resize: vertical;
        }

        .file-info {
            font-size: 12px;
            color: var(--text-muted);
            margin-top: 6px;
            display: block;
        }

        /* --- Main Submit Button Style Updates --- */
        .btn { 
            padding: 14px 24px; 
            border: none; 
            border-radius: 12px; 
            font-weight: 700; 
            cursor: pointer; 
            font-size: 15px; 
            width: 100%; 
            box-sizing: border-box;
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
            margin-top: 10px;
        }

        .btn-success { 
            background: rgba(255, 255, 255, 0.02); 
            color: var(--text-heading); 
            border: 1px solid rgba(255, 255, 255, 0.04);
        }
        .btn-success:hover { 
            background: rgba(168, 85, 247, 0.16); 
            border-color: rgba(168, 85, 247, 0.4);
            color: white; 
            box-shadow: 0 0 20px rgba(168, 85, 247, 0.4);
        }

        .alert-error { 
            padding: 16px; 
            border-radius: 12px; 
            margin-bottom: 25px; 
            background: rgba(244, 63, 148, 0.1); 
            color: var(--accent-rose); 
            border: 1px solid rgba(244, 63, 148, 0.2); 
            font-weight: 600;
            max-width: 600px;
            box-sizing: border-box;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <h1>UniTransit</h1>
    <p>Driver Hub Panel</p>
    
    <div style="background: rgba(255,255,255,0.03); border: 1px solid var(--border-glow); padding: 16px; border-radius: 12px; margin-bottom: 20px; text-align: center;">
        <% if(!licenseCard.isEmpty()) { %>
            <img src="<%= licenseCard %>" alt="License Preview" style="width: 80px; height: 80px; border-radius: 50%; object-fit: cover; margin-bottom: 12px; border: 2px solid var(--primary-glow); box-shadow: 0 0 10px rgba(168, 85, 247, 0.4);" />
        <% } else { %>
            <div style="width: 80px; height: 80px; border-radius: 50%; background: rgba(255,255,255,0.05); margin: 0 auto 12px auto; display: flex; align-items: center; justify-content: center; border: 2px dashed var(--border-glow); color: var(--text-muted); font-size: 12px;">No Image</div>
        <% } %>
        
        <span style="color: var(--text-muted); display:block; font-size:10px; text-transform:uppercase; font-weight:700; letter-spacing:0.05em; text-align: left;">Driver Account</span>
        <strong style="color: var(--text-heading); font-size: 15px; display: block; text-align: left; margin-top: 2px;"><%= session.getAttribute("username") %></strong>
    </div>
    
    <a href="main" style="margin-bottom: 8px;">&larr; Back to Dashboard</a>
    <a href="main?action=logout">Terminal Logout</a>
</div>

<div class="main-content">
    <% if(request.getParameter("error") != null) { %>
        <div class="alert-error">Failed to update profile details: <%= request.getParameter("error").replace("_", " ") %></div>
    <% } %>

    <div class="card">
        <h3>Edit Hub Profile</h3>
        
        <form action="main?action=updateProfile" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label>Username Identification</label>
                <input type="text" name="username" class="input-field" value="<%= username %>" required />
            </div>
            
            <div class="form-group">
                <label>Contact Phone Number</label>
                <input type="text" name="phone" class="input-field" value="<%= phone %>" placeholder="e.g. +60123456789" />
            </div>
            
            <div class="form-group">
                <label>Vehicle Model Information</label>
                <input type="text" name="vehicle_info" class="input-field" value="<%= vehicleInfo %>" placeholder="e.g. Proton Saga (VAA 1234)" />
            </div>
            
            <div class="form-group">
                <label>Driver Biography / Notes</label>
                <textarea name="bio" class="input-field" rows="4" placeholder="Tell passengers about yourself..."><%= bio %></textarea>
            </div>
            
            <div class="form-group">
                <label>Update Verified License Document (Image)</label>
                <input type="file" name="licenseFile" class="input-field" accept="image/*" />
                <% if(!licenseCard.isEmpty() && !"uploads/license/default.png".equals(licenseCard)) { %>
                    <span class="file-info">Active Server Matrix Document: <%= licenseCard %></span>
                <% } %>
            </div>
            
            <button type="submit" class="btn btn-success">Commit Dynamic Updates</button>
        </form>
    </div>
</div>

</body>
</html>