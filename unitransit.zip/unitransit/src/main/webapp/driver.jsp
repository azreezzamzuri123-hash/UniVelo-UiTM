<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.Map, java.util.List" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>UniTransit | Driver Hub</title>
    <style>
        :root {
            --bg-main: #060913;
            --panel-bg: #0d1222;
            --card-bg: #121a32;
            --primary-glow: #a855f7;
            --secondary-glow: #e879f9;
            --accent-emerald: #10b981;
            --accent-rose: #f43f5e;
            --text-heading: #f8fafc;
            --text-body: #cbd5e1;
            --text-muted: #64748b;
            --border-glow: #1e293b;
        }

        body { 
            font-family: 'Inter', system-ui, -apple-system, sans-serif; 
            background-color: var(--bg-main); 
            margin: 0; 
            display: flex; 
            color: var(--text-body); 
            letter-spacing: -0.01em;
        }

        .sidebar { 
            width: 280px; 
            background-color: var(--panel-bg); 
            height: 100vh; 
            padding: 30px 24px; 
            box-sizing: border-box; 
            border-right: 1px solid var(--border-glow); 
            position: fixed; 
        }

        .sidebar h1 { 
            font-size: 1.6rem;
            font-weight: 800;
            background: linear-gradient(to right, var(--primary-glow), var(--secondary-glow));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin: 0 0 5px 0; 
        }

        .sidebar p { color: var(--text-muted); margin: 5px 0 25px 0; font-size: 14px; font-weight: 500; }
        
        /* --- Sidebar Navigation Links --- */
        .sidebar a { 
            display: block; 
            color: #94a3b8; 
            text-decoration: none; 
            padding: 14px 20px; 
            font-weight: 600; 
            font-size: 15px;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid rgba(255, 255, 255, 0.04);
            margin-bottom: 12px;
            box-sizing: border-box;
            transition: all 0.2s ease;
        }
        
        .sidebar a:hover { 
            color: white; 
            background: rgba(168, 85, 247, 0.16);
            border-color: rgba(168, 85, 247, 0.4);
            box-shadow: 0 0 20px rgba(168, 85, 247, 0.4);
        }

        /* Specific override for Logout to keep its distinct danger tint */
        .sidebar a[href*="logout"] {
            color: var(--accent-rose);
            background: rgba(244, 63, 94, 0.03);
            border-color: rgba(244, 63, 94, 0.1);
            margin-top: 20px;
        }
        .sidebar a[href*="logout"]:hover {
            background: rgba(244, 63, 94, 0.15);
            border-color: rgba(244, 63, 94, 0.4);
            box-shadow: 0 0 20px rgba(244, 63, 94, 0.4);
            color: #ff4d6d;
        }

        .main-content { flex: 1; padding: 40px; margin-left: 280px; box-sizing: border-box; background-color: var(--bg-main); }
        
        .card { 
            background: var(--card-bg); 
            padding: 30px; 
            border-radius: 16px; 
            border: 1px solid var(--border-glow); 
            margin-bottom: 30px; 
            box-shadow: 0 20px 40px -15px rgba(0,0,0,0.5);
            position: relative;
            overflow: hidden;
        }

        .card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; height: 1px;
            background: linear-gradient(90deg, transparent, rgba(139, 92, 246, 0.2), transparent);
        }

        .card h3 { margin-top: 0; color: var(--text-heading); font-size: 1.25rem; font-weight: 700; margin-bottom: 20px; }
        
        .input-bid { 
            width: 100%; 
            padding: 14px; 
            background: rgba(6, 9, 19, 0.6); 
            border: 1px solid var(--border-glow); 
            border-radius: 8px; 
            color: white; 
            font-size: 16px; 
            box-sizing: border-box; 
            margin-bottom: 15px; 
            transition: border-color 0.2s;
        }
        .input-bid:focus { border-color: var(--primary-glow); outline: none; }

        /* --- Action Buttons --- */
        .btn { 
            padding: 14px 24px; 
            border: none; 
            border-radius: 12px; 
            font-weight: 700; 
            cursor: pointer; 
            font-size: 15px; 
            width: 100%; 
            box-sizing: border-box;
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .btn-success { 
            background: rgba(255, 255, 255, 0.02); 
            color: var(--text-heading); 
            border: 1px solid rgba(255, 255, 255, 0.04);
        }
        .btn-success:hover { 
            background: rgba(168, 85, 247, 0.16); 
            border-color: rgba(168, 85, 247, 0.4);
            color: white; 
            box-shadow: 0 0 20px rgba(168, 85, 247, 0.4);
        }

        .market-item { 
            background: rgba(255, 255, 255, 0.02); 
            padding: 24px; 
            border-radius: 12px; 
            margin-bottom: 20px; 
            border: 1px solid var(--border-glow); 
            transition: all 0.2s ease;
        }
        .market-item:hover {
            border-color: rgba(168, 85, 247, 0.3);
            background: rgba(255, 255, 255, 0.03);
        }

        .table-header {
            display: grid;
            grid-template-columns: 1fr 2fr 2fr 1.5fr 1.2fr;
            padding: 12px 20px;
            color: var(--text-muted);
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .table-row {
            display: grid;
            grid-template-columns: 1fr 2fr 2fr 1.5fr 1.2fr;
            align-items: center;
            padding: 16px 20px;
            background: rgba(255, 255, 255, 0.01);
            border: 1px solid var(--border-glow);
            border-radius: 10px;
            margin-bottom: 8px;
            transition: all 0.2s ease;
        }
        .table-row:hover {
            background: rgba(255, 255, 255, 0.03);
            border-color: rgba(139, 92, 246, 0.2);
        }

        .alert { 
            padding: 16px; 
            border-radius: 12px; 
            margin-bottom: 25px; 
            background: rgba(16, 185, 129, 0.1); 
            color: var(--accent-emerald); 
            border: 1px solid rgba(16, 185, 129, 0.2); 
            font-weight: 600;
        }
        
        .type-tag {
            font-size: 11px;
            background: rgba(139, 92, 246, 0.15);
            padding: 4px 10px;
            border-radius: 20px;
            border: 1px solid rgba(139, 92, 246, 0.3);
            color: #c084fc;
            font-weight: 600;
            display: inline-block;
        }

        .loading-container { display: flex; align-items: center; gap: 12px; color: var(--text-muted); font-size: 14px; font-weight: 500; margin-top: 10px; }
        .spinner { width: 20px; height: 20px; border: 3px solid var(--border-glow); border-top-color: var(--primary-glow); border-radius: 50%; animation: spin 0.8s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }
    </style>
</head>
<body>

<div class="sidebar">
    <h1>UniTransit</h1>
    <p>Driver Hub Panel</p>
    
    <div style="background: rgba(255,255,255,0.03); border: 1px solid var(--border-glow); padding: 16px; border-radius: 12px; margin-bottom: 20px; text-align: center;">
        <% 
            Map<String, Object> meMap = (Map<String, Object>) request.getAttribute("me");
            String licenseImg = (meMap != null) ? (String) meMap.get("photo") : null;
            if (licenseImg != null && !licenseImg.trim().isEmpty() && !licenseImg.contains("default.png")) { 
        %>
            <img src="<%= licenseImg %>" alt="License Card Profile Preview" style="width: 80px; height: 80px; border-radius: 50%; object-fit: cover; margin: 0 auto 12px auto; display: block; border: 2px solid var(--primary-glow); box-shadow: 0 0 14px rgba(168, 85, 247, 0.45);" />
        <% } else { %>
            <div style="width: 80px; height: 80px; border-radius: 50%; background: rgba(255,255,255,0.04); margin: 0 auto 12px auto; display: flex; align-items: center; justify-content: center; border: 2px dashed var(--border-glow); color: var(--text-muted); font-size: 11px;">No Image</div>
        <% } %>
        
        <span style="color: var(--text-muted); display:block; font-size:10px; text-transform:uppercase; font-weight:700; letter-spacing:0.05em; text-align: left;">Driver Account</span>
        <strong style="color: var(--text-heading); font-size: 15px; display: block; text-align: left; margin-top: 2px;"><%= session.getAttribute("username") %></strong>
    </div>
    
    <a href="main?action=profile">Edit Hub Profile</a>
    <a href="main?action=logout">Terminal Logout</a>
</div>

<div class="main-content">
    <% if(request.getParameter("msg") != null) { %>
        <div class="alert"><%= request.getParameter("msg") %></div>
    <% } %>

    <div class="card">
        <h3>Current Job Assignment</h3>
        <div id="dynamicJobContainer">
            <% 
                Map<String, Object> job = (Map<String, Object>) request.getAttribute("activeJob");
                if (job == null) { 
            %>
                <p style="color: var(--text-muted); margin: 0; font-style: italic;">Looking for open ride requests on campus...</p>
            <% } else { %>
                <div style="background: rgba(255,255,255,0.01); padding: 24px; border-radius: 12px; border: 1px solid var(--border-glow); border-left: 4px solid var(--accent-emerald);">
                    <p style="margin-top:0; font-size: 16px;"><strong>Route:</strong> <%= job.get("pickup") != null ? job.get("pickup") : job.get("pickup_loc") %> &rarr; <%= job.get("dropoff") != null ? job.get("dropoff") : job.get("dropoff_loc") %></p>
                    <p><strong>Your Offer Price:</strong> <span style="color: var(--text-heading); font-weight: 700;">RM <%= String.format("%.2f", job.get("fare") != null ? job.get("fare") : job.get("quoted_fare")) %></span></p>
                    <p><strong>Status:</strong> <span style="color: #f59e0b; font-weight:bold; background: rgba(245,158,11,0.1); padding: 4px 10px; border-radius: 6px;"><%= job.get("status") %></span></p>

                    <% if ("OFFERED".equals(job.get("status"))) { %>
                        <div class="loading-container">
                            <div class="spinner"></div>
                            <span>Waiting for passenger approval...</span>
                        </div>
                    <% } else if ("ACCEPTED".equals(job.get("status"))) { %>
                        <form action="main" method="POST" style="margin-top: 20px;">
                            <input type="hidden" name="action" value="settleRide" />
                            <input type="hidden" name="requestId" value="<%= job.get("id") %>" />
                            <button type="submit" class="btn btn-success">Complete Trip & Collect Fare</button>
                        </form>
                    <% } %>
                </div>
            <% } %>
        </div>
    </div>

    <div class="card">
        <h3>Available Marketplace Trips</h3>
        <div id="dynamicMarketFeed">
            <% 
                List<Map<String, Object>> market = (List<Map<String, Object>>) request.getAttribute("market");
                if (market == null || market.isEmpty()) {
            %>
                <p style="color: var(--text-muted); margin: 0; font-style: italic;">No active requests from passengers at the moment.</p>
            <% } else { 
                for (Map<String, Object> req : market) {
            %>
                <div class="market-item" id="market-item-<%= req.get("id") %>">
                    <p style="margin-top:0; font-size: 16px; color: var(--text-heading);"><strong>Route:</strong> <%= req.get("pickup") != null ? req.get("pickup") : req.get("pickup_loc") %> &rarr; <%= req.get("dropoff") != null ? req.get("dropoff") : req.get("dropoff_loc") %></p>
                    
                    <form action="main" method="POST" style="margin-top: 20px;" onsubmit="showBidLoading(this)">
                        <input type="hidden" name="action" value="acceptRequest" />
                        <input type="hidden" name="requestId" value="<%= req.get("id") %>" />
                        <label style="display:block; margin-bottom:8px; color: var(--text-body); font-size: 14px; font-weight: 500;">Your Fare Offer (RM)</label>
                        <input type="number" step="0.01" name="fare" class="input-bid" placeholder="e.g. 6.50" required />
                        <div class="bid-action-area">
                            <button type="submit" class="btn btn-success">Submit Custom Bid Offer</button>
                        </div>
                    </form>
                </div>
            <% 
                } 
            } 
            %>
        </div>
    </div>

    <div class="card">
        <h3>Completed Trips History</h3>
        <div id="driverHistoryTable">
            <div class="table-header">
                <div>Job ID</div>
                <div>Pickup</div>
                <div>Dropoff</div>
                <div>Vehicle Fleet</div>
                <div>Fare Collected</div>
            </div>
            <div class="table-body">
                <% 
                    List<Map<String, Object>> history = (List<Map<String, Object>>) request.getAttribute("history");
                    if (history != null && !history.isEmpty()) {
                        for (Map<String, Object> h : history) {
                %>
                    <div class="table-row">
                        <div style="color: var(--primary-glow); font-weight: 700;">#<%= h.get("id") %></div>
                        <div><%= h.get("pickup") != null ? h.get("pickup") : h.get("pickup_loc") %></div>
                        <div><%= h.get("dropoff") != null ? h.get("dropoff") : h.get("dropoff_loc") %></div>
                        <div><span class="type-tag"><%= h.get("type") != null ? h.get("type") : (h.get("vehicle_type") != null ? h.get("vehicle_type") : "Standard Sedan") %></span></div>
                        <div style="color: var(--accent-emerald); font-weight: 700;">RM <%= String.format("%.2f", h.get("fare") != null ? h.get("fare") : (h.get("final_fare") != null ? h.get("final_fare") : h.get("quoted_fare"))) %></div>
                    </div>
                <% 
                        }
                    } else { 
                %>
                    <div style="text-align: center; color: var(--text-muted); padding: 30px; font-style: italic;">No completed trips found.</div>
                <% } %>
            </div>
        </div>
    </div>
</div>

<script>
    let currentlyHasActiveJob = <%= job != null %>;

    function showBidLoading(formElement) {
        const actionArea = formElement.querySelector('.bid-action-area');
        if(actionArea) {
            actionArea.innerHTML = '<div class="loading-container"><div class="spinner"></div><span>Sending bid price details...</span></div>';
        }
    }

    function pollDriverMatrix() {
        fetch('main?action=getDashboardData')
            .then(response => response.json())
            .then(data => {
                if (data.hasActiveJob !== currentlyHasActiveJob) {
                    location.reload();
                    return;
                }

                const jobContainer = document.getElementById('dynamicJobContainer');
                if (data.hasActiveJob && jobContainer) {
                    const jobObj = data.job;
                    const pLoc = jobObj.pickup || jobObj.pickup_loc || 'N/A';
                    const dLoc = jobObj.dropoff || jobObj.dropoff_loc || 'N/A';
                    const fareVal = jobObj.fare || jobObj.quoted_fare || 0;

                    let jobHtml = `
                        <div style="background: rgba(255,255,255,0.01); padding: 24px; border-radius: 12px; border: 1px solid var(--border-glow); border-left: 4px solid var(--accent-emerald);">
                            <p style="margin-top:0; font-size: 16px;"><strong>Route:</strong> \${pLoc} &rarr; \${dLoc}</p>
                            <p><strong>Your Offer Price:</strong> <span style="color: var(--text-heading); font-weight: 700;">RM \${parseFloat(fareVal).toFixed(2)}</span></p>
                            <p><strong>Status:</strong> <span style="color: #f59e0b; font-weight:bold; background: rgba(245,158,11,0.1); padding: 4px 10px; border-radius: 6px;">\${jobObj.status}</span></p>
                    `;
                    if (jobObj.status === 'OFFERED') {
                        jobHtml += `
                            <div class="loading-container">
                                <div class="spinner"></div>
                                <span>Waiting for passenger approval...</span>
                            </div>
                        `;
                    } else if (jobObj.status === 'ACCEPTED') {
                        jobHtml += `
                            <form action="main" method="POST" style="margin-top: 20px;">
                                <input type="hidden" name="action" value="settleRide" />
                                <input type="hidden" name="requestId" value="\${jobObj.id}" />
                                <button type="submit" class="btn btn-success">Complete Trip & Collect Fare</button>
                            </form>
                        `;
                    }
                    jobHtml += `</div>`;
                    jobContainer.innerHTML = jobHtml;
                }

                const marketFeed = document.getElementById('dynamicMarketFeed');
                if (!data.hasActiveJob && marketFeed) {
                    if (data.market.length === 0) {
                        marketFeed.innerHTML = `<p style="color: var(--text-muted); margin: 0; font-style: italic;">No active requests from campus at the moment.</p>`;
                    } else {
                        data.market.forEach(req => {
                            let itemExists = document.getElementById(`market-item-\${req.id}`);
                            if (!itemExists) {
                                const mp = req.pickup || req.pickup_loc || 'N/A';
                                const md = req.dropoff || req.dropoff_loc || 'N/A';
                                let div = document.createElement('div');
                                div.className = 'market-item';
                                div.id = `market-item-\${req.id}`;
                                div.innerHTML = `
                                    <p style="margin-top:0; font-size: 16px; color: var(--text-heading);"><strong>Route:</strong> \${mp} &rarr; \${md}</p>
                                    <form action="main" method="POST" style="margin-top: 20px;" onsubmit="showBidLoading(this)">
                                        <input type="hidden" name="action" value="acceptRequest" />
                                        <input type="hidden" name="requestId" value="\${req.id}" />
                                        <label style="display:block; margin-bottom:8px; color: var(--text-body); font-size: 14px; font-weight: 500;">Your Fare Offer (RM)</label>
                                        <input type="number" step="0.01" name="fare" class="input-bid" placeholder="e.g. 6.50" required />
                                        <div class="bid-action-area">
                                            <button type="submit" class="btn btn-success">Submit Custom Bid Offer</button>
                                        </div>
                                    </form>
                                `;
                                marketFeed.appendChild(div);
                            }
                        });

                        const renderedItems = marketFeed.getElementsByClassName('market-item');
                        for(let i = renderedItems.length - 1; i >= 0; i--) {
                            let itemId = parseInt(renderedItems[i].id.replace('market-item-', ''));
                            if (!data.market.some(m => m.id === itemId)) {
                                renderedItems[i].remove();
                            }
                        }
                    }
                }

                const historyBody = document.querySelector('#driverHistoryTable .table-body');
                if (historyBody && data.history) {
                    if (data.history.length === 0) {
                        historyBody.innerHTML = `<div style="text-align: center; color: var(--text-muted); padding: 30px; font-style: italic;">No completed trips found.</div>`;
                    } else {
                        let historyHtml = "";
                        data.history.forEach(h => {
                            const hp = h.pickup || h.pickup_loc || 'N/A';
                            const hd = h.dropoff || h.dropoff_loc || 'N/A';
                            const hf = h.type || h.vehicle_type || 'Standard Sedan';
                            const hcf = h.fare || h.final_fare || h.quoted_fare || 0;
                            historyHtml += `<div class="table-row">
                                <div style="color: var(--primary-glow); font-weight: 700;">#\${h.id}</div>
                                <div>\${hp}</div>
                                <div>\${hd}</div>
                                <div><span class="type-tag">\${hf}</span></div>
                                <div style="color: var(--accent-emerald); font-weight: 700;">RM \${parseFloat(hcf).toFixed(2)}</div>
                            </div>`;
                        });
                        historyBody.innerHTML = historyHtml;
                    }
                }
            }).catch(err => console.error("Refresh sync paused."));
    }

    setInterval(pollDriverMatrix, 3000);
</script>
</body>
</html>