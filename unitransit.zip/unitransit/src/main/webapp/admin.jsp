<%@page import="com.unitransit.config.DBConfig"%>
<%@page import="java.sql.*"%>
<%@page import="java.util.List"%>
<%@page import="java.util.Map"%>
<%@page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>UniTransit - Control Deck</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/style.css?v=<%= System.currentTimeMillis() %>">
    <style>
        /* Primary Domain Navigation Tabs */
        .primary-tabs {
            display: flex;
            gap: 12px;
            margin-bottom: 2rem;
            border-bottom: 2px solid rgba(255, 255, 255, 0.05);
            padding-bottom: 12px;
        }
        .main-tab-btn {
            background: transparent;
            border: 1px solid transparent;
            color: var(--text-muted);
            padding: 10px 24px;
            font-size: 14px;
            font-weight: 600;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        .main-tab-btn:hover {
            color: var(--text-heading);
            background: rgba(255, 255, 255, 0.02);
        }
        .main-tab-btn.active {
            background: rgba(255, 255, 255, 0.06);
            border-color: var(--border-glow);
            color: var(--text-heading);
        }

        /* Nested Internal User View Filter Sub-Tabs Layout */
        .sub-tabs-container {
            display: flex;
            gap: 10px;
            margin: 1.5rem 0;
            background: rgba(0, 0, 0, 0.2);
            padding: 6px;
            border-radius: 10px;
            width: fit-content;
            border: 1px solid rgba(255, 255, 255, 0.03);
        }
        .sub-tab-btn {
            background: transparent;
            border: none;
            color: var(--text-muted);
            padding: 8px 18px;
            font-size: 13px;
            font-weight: 500;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.15s ease;
        }
        .sub-tab-btn:hover {
            color: var(--text-heading);
        }
        .sub-tab-btn.active {
            background: var(--text-heading);
            color: #0d1117;
            font-weight: 600;
        }

        /* View Panels Structural Display Toggles */
        .panel-view { display: none; }
        .panel-view.active { display: block; }
        .db-sub-view { display: none; }
        .db-sub-view.active { display: block; }

        /* --- Sidebar Navigation Links matching image_916109.png --- */
        .sidebar-navy a.nav-link {
            display: block;
            color: #94a3b8;
            text-decoration: none;
            padding: 14px 20px;
            font-weight: 600;
            font-size: 15px;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid rgba(255, 255, 255, 0.04);
            margin-bottom: 12px;
            box-sizing: border-box;
            transition: all 0.2s ease;
        }
        .sidebar-navy a.nav-link:hover {
            color: white;
            background: rgba(168, 85, 247, 0.16);
            border-color: rgba(168, 85, 247, 0.4);
            box-shadow: 0 0 20px rgba(168, 85, 247, 0.4);
        }

        /* Specific override for Logout to keep its distinct danger tint */
        .sidebar-navy a.nav-link[href*="logout"] {
            color: var(--accent-rose);
            background: rgba(244, 63, 94, 0.03);
            border-color: rgba(244, 63, 94, 0.1);
        }
        .sidebar-navy a.nav-link[href*="logout"]:hover {
            background: rgba(244, 63, 94, 0.15);
            border-color: rgba(244, 63, 94, 0.4);
            box-shadow: 0 0 20px rgba(244, 63, 94, 0.4);
            color: #ff4d6d;
        }

        /* --- Action Buttons (Main Panel) matching the same style --- */
        .btn {
            display: inline-block;
            text-align: center;
            text-decoration: none;
            padding: 10px 20px;
            border: none;
            border-radius: 12px;
            font-weight: 700;
            cursor: pointer;
            font-size: 14px;
            box-sizing: border-box;
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .btn-success {
            background: rgba(255, 255, 255, 0.02);
            color: var(--text-heading);
            border: 1px solid rgba(255, 255, 255, 0.04);
        }
        .btn-success:hover {
            background: rgba(168, 85, 247, 0.16);
            border-color: rgba(168, 85, 247, 0.4);
            color: white;
            box-shadow: 0 0 20px rgba(168, 85, 247, 0.4);
        }

        .btn-danger {
            background: rgba(244, 63, 94, 0.03);
            color: var(--accent-rose);
            border: 1px solid rgba(244, 63, 94, 0.1);
        }
        .btn-danger:hover {
            background: rgba(244, 63, 94, 0.15);
            border-color: rgba(244, 63, 94, 0.4);
            box-shadow: 0 0 20px rgba(244, 63, 94, 0.4);
            color: #ff4d6d;
        }
        
        .action-box {
            display: flex;
            gap: 8px;
            justify-content: center;
            align-items: center;
        }
    </style>
    <script>
        function toggleMainView(viewId) {
            document.querySelectorAll('.panel-view').forEach(el => el.classList.remove('active'));
            document.querySelectorAll('.main-tab-btn').forEach(el => el.classList.remove('active'));
            
            document.getElementById(viewId + '-panel').classList.add('active');
            document.getElementById(viewId + '-btn').classList.add('active');
        }

        function toggleSubDatabase(subId) {
            document.querySelectorAll('.db-sub-view').forEach(el => el.classList.remove('active'));
            document.querySelectorAll('.sub-tab-btn').forEach(el => el.classList.remove('active'));
            
            document.getElementById(subId + '-subview').classList.add('active');
            document.getElementById(subId + '-btn').classList.add('active');
        }
    </script>
</head>
<body>
<%
    String role = (String) session.getAttribute("role");
    if (!"ADMIN".equals(role)) {
        response.sendRedirect("login.jsp?error=Unauthorized System Vector Access Request Rejected.");
        return;
    }
    String adminName = (String) session.getAttribute("username");
    
    List<Map<String, Object>> regPassengers = (List<Map<String, Object>>) request.getAttribute("registeredPassengers");
    List<Map<String, Object>> regDrivers = (List<Map<String, Object>>) request.getAttribute("registeredDrivers");
%>

<div class="dashboard-container">
    
    <div class="sidebar-navy" style="padding: 24px; box-sizing: border-box;">
        <h2>UniTransit</h2>
        <p style="color: var(--text-muted); font-size: 13px; font-weight: 500; margin-top: 0;">Enterprise Operations</p>
        
        <div style="background: rgba(255,255,255,0.03); border: 1px solid var(--border-glow); padding: 16px; border-radius: 12px; margin-top: 2rem; margin-bottom: 2rem;">
            <span style="color: var(--text-muted); display:block; font-size:10px; text-transform:uppercase; font-weight:700; letter-spacing: 0.05em;">Console Admin</span>
            <strong style="color: var(--text-heading); font-size: 15px;"><%= adminName %></strong>
        </div>
        
        <a href="main?action=logout" class="nav-link">Terminal Logout</a>
    </div>

    <div class="main-content" style="flex: 1; padding: 3rem; margin-left: 280px; box-sizing: border-box;">
        
        <% if (request.getParameter("msg") != null) { %>
            <div class="status-alert"><%= request.getParameter("msg") %></div>
        <% } %>

        <div class="primary-tabs">
            <button id="approvals-btn" class="main-tab-btn active" onclick="toggleMainView('approvals')">Pending Registrations</button>
            <button id="records-btn" class="main-tab-btn" onclick="toggleMainView('records')">Registered User Database</button>
        </div>

        <div id="approvals-panel" class="panel-view active">
            <div class="app-card-wide">
                <h3>Pending Passenger Verifications</h3>
                <div class="data-header">
                    <div>Account Handle</div>
                    <div>Phone Record</div>
                    <div>Uploaded Student Proof</div>
                    <div style="text-align: center;">Clearance Actions</div>
                </div>

                <%
                    int passengerCount = 0;
                    try (Connection conn = DBConfig.getConnection()) {
                        String sql = "SELECT id, username, phone, student_card_path FROM passengers WHERE account_status = 'PENDING'";
                        try (PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
                            while (rs.next()) {
                                passengerCount++;
                %>
                                <div class="data-row">
                                    <div><strong style="color: var(--text-heading);"><%= rs.getString("username") %></strong></div>
                                    <div><%= rs.getString("phone") %></div>
                                    <div>
                                        <a href="<%= rs.getString("student_card_path") %>" target="_blank" class="text-link">Review Document ↗</a>
                                    </div>
                                    <div class="action-box">
                                        <a href="main?action=verifyPassenger&id=<%= rs.getInt("id") %>&status=APPROVED" class="btn btn-success">Approve</a>
                                        <a href="main?action=verifyPassenger&id=<%= rs.getInt("id") %>&status=REJECTED" class="btn btn-danger">Reject</a>
                                    </div>
                                </div>
                <%
                            }
                        }
                    } catch (Exception e) {
                        out.println("<div style='color:var(--accent-rose); padding:15px;'>System Data Stream Error: " + e.getMessage() + "</div>");
                    }
                    if (passengerCount == 0) {
                %>
                        <div style="color: var(--text-muted); font-style: italic; text-align: center; padding: 40px; background: rgba(255,255,255,0.01); border-radius:12px; border: 1px dashed var(--border-glow);">
                            No passenger verification requests are queueing in the operations ledger.
                        </div>
                <% } %>
            </div>

            <div class="app-card-wide" style="margin-top: 2.5rem;">
                <h3>Pending Driver Profile Verifications</h3>
                <div class="data-header">
                    <div>Operator Handle</div>
                    <div>Phone Vector</div>
                    <div>Vehicle Asset Blueprint</div>
                    <div style="text-align: center;">Clearance Actions</div>
                </div>

                <%
                    int driverCount = 0;
                    try (Connection conn = DBConfig.getConnection()) {
                        String sql = "SELECT d.id, d.username, d.phone, d.license_card_path, v.vehicle_type, v.model_info, v.plate_number " +
                                     "FROM drivers d JOIN vehicles v ON d.id = v.driver_id WHERE d.verification_status = 'PENDING'";
                        try (PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
                            while (rs.next()) {
                                driverCount++;
                %>
                                <div class="data-row">
                                    <div><strong style="color: var(--text-heading);"><%= rs.getString("username") %></strong></div>
                                    <div><%= rs.getString("phone") %></div>
                                    <div>
                                        <span class="type-tag"><%= rs.getString("vehicle_type") %></span>
                                        <div style="font-size: 13px; margin-top: 4px; color: var(--text-heading);"><%= rs.getString("model_info") %></div>
                                        <div style="font-size: 11px; color: var(--text-muted);"><%= rs.getString("plate_number") %></div>
                                        <a href="<%= rs.getString("license_card_path") %>" target="_blank" class="text-link" style="font-size: 12px; display:inline-block; margin-top:6px;">View License ↗</a>
                                    </div>
                                    <div class="action-box">
                                        <a href="main?action=verifyDriver&id=<%= rs.getInt("id") %>&status=APPROVED" class="btn btn-success">Verify</a>
                                        <a href="main?action=verifyDriver&id=<%= rs.getInt("id") %>&status=REJECTED" class="btn btn-danger">Drop</a>
                                    </div>
                                </div>
                <%
                            }
                        }
                    } catch (Exception e) {
                        out.println("<div style='color:var(--accent-rose); padding:15px;'>System Data Stream Error: " + e.getMessage() + "</div>");
                    }
                    if (driverCount == 0) {
                %>
                        <div style="color: var(--text-muted); font-style: italic; text-align: center; padding: 40px; background: rgba(255,255,255,0.01); border-radius:12px; border: 1px dashed var(--border-glow);">
                            No driver accounts are currently awaiting structural clearance logs.
                        </div>
                <% } %>
            </div>
        </div>


        <div id="records-panel" class="panel-view">
            
            <div style="margin-bottom: 1rem;">
                <h3 style="margin-bottom: 0.2rem;">Registered Platform Users</h3>
                <p style="color: var(--text-muted); font-size: 14px; margin: 0;">Review clear structural system profiles across all active nodes.</p>
            </div>

            <div class="sub-tabs-container">
                <button id="passengers-btn" class="sub-tab-btn active" onclick="toggleSubDatabase('passengers')">Passengers Ledger</button>
                <button id="drivers-btn" class="sub-tab-btn" onclick="toggleSubDatabase('drivers')">Drivers Ledger</button>
            </div>

            <div id="passengers-subview" class="db-sub-view active">
                <div class="app-card-wide">
                    <div class="data-header">
                        <div>Account Handle</div>
                        <div>Phone Record</div>
                        <div>Bio Manifest Matrix</div>
                        <div>Verification Identity</div>
                        <div style="text-align: center;">Account Ledger Status</div>
                    </div>
                    <%
                        if (regPassengers != null && !regPassengers.isEmpty()) {
                            for (Map<String, Object> p : regPassengers) {
                    %>
                                <div class="data-row">
                                    <div>
                                        <strong style="color: var(--text-heading);"><%= p.get("username") %></strong>
                                        <span style="font-size:11px; color:var(--text-muted); display:inline-block; margin-left:6px;">#<%= p.get("id") %></span>
                                    </div>
                                    <div><%= p.get("phone") %></div>
                                    <div style="font-size: 13px; color: var(--text-muted);"><%= p.get("bio") %></div>
                                    <div>
                                        <% if (p.get("student_card") != null) { %>
                                            <a href="<%= p.get("student_card") %>" target="_blank" class="text-link" style="font-size: 13px;">Review Card ↗</a>
                                        <% } else { %>
                                            <span style="color: var(--text-muted); font-style: italic; font-size:13px;">No Card Found</span>
                                        <% } %>
                                    </div>
                                    <div style="text-align: center;">
                                        <span class="badge-btn <%= "APPROVED".equals(p.get("status")) ? "badge-btn-success" : "badge-btn-danger" %>" style="pointer-events: none; padding: 4px 12px; font-size:11px; opacity: 0.85;">
                                            <%= p.get("status") %>
                                        </span>
                                    </div>
                                </div>
                    <%
                            }
                        } else {
                    %>
                            <div style="color: var(--text-muted); font-style: italic; text-align: center; padding: 40px; background: rgba(255,255,255,0.01); border-radius:12px; border: 1px dashed var(--border-glow);">
                                No registered passenger data sets located inside database clusters.
                            </div>
                    <%  } %>
                </div>
            </div>

            <div id="drivers-subview" class="db-sub-view">
                <div class="app-card-wide">
                    <div class="data-header">
                        <div>Operator Handle</div>
                        <div>Phone Vector</div>
                        <div>Assigned Vehicle Node Specification</div>
                        <div>Verification Identity</div>
                        <div style="text-align: center;">Account Ledger Status</div>
                    </div>
                    <%
                        if (regDrivers != null && !regDrivers.isEmpty()) {
                            for (Map<String, Object> d : regDrivers) {
                    %>
                                <div class="data-row">
                                    <div>
                                        <strong style="color: var(--text-heading);"><%= d.get("username") %></strong>
                                        <span style="font-size:11px; color:var(--text-muted); display:inline-block; margin-left:6px;">#<%= d.get("id") %></span>
                                    </div>
                                    <div><%= d.get("phone") %></div>
                                    <div>
                                        <% if (d.get("vehicle_type") != null) { %>
                                            <span class="type-tag"><%= d.get("vehicle_type") %></span>
                                            <div style="font-size: 13px; margin-top: 4px; color: var(--text-heading);"><%= d.get("model_info") %></div>
                                            <div style="font-size: 11px; color: var(--text-muted);"><%= d.get("plate_number") %></div>
                                        <% } else { %>
                                            <span style="color: var(--text-muted); font-style: italic; font-size:13px;">No active vehicle record connected.</span>
                                        <% } %>
                                    </div>
                                    <div>
                                        <% if (d.get("license_card") != null) { %>
                                            <a href="<%= d.get("license_card") %>" target="_blank" class="text-link" style="font-size: 13px;">Review License ↗</a>
                                        <% } else { %>
                                            <span style="color: var(--text-muted); font-style: italic; font-size:13px;">No Document Found</span>
                                        <% } %>
                                    </div>
                                    <div style="text-align: center;">
                                        <span class="badge-btn <%= "APPROVED".equals(d.get("status")) ? "badge-btn-success" : "badge-btn-danger" %>" style="pointer-events: none; padding: 4px 12px; font-size:11px; opacity: 0.85;">
                                            <%= d.get("status") %>
                                        </span>
                                    </div>
                                </div>
                    <%
                            }
                        } else {
                    %>
                            <div style="color: var(--text-muted); font-style: italic; text-align: center; padding: 40px; background: rgba(255,255,255,0.01); border-radius:12px; border: 1px dashed var(--border-glow);">
                                No registered driver data sets located inside database clusters.
                            </div>
                    <%  } %>
                </div>
            </div>

        </div>

    </div>
</div>
</body>
</html>