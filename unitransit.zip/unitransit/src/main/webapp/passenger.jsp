<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.Map, java.util.List" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>UniTransit | Passenger Hub</title>
    <style>
        :root {
            --bg-main: #060913;
            --panel-bg: #0d1222;
            --card-bg: #121a32;
            --primary-glow: #a855f7;
            --secondary-glow: #e879f9;
            --accent-emerald: #10b981;
            --accent-rose: #f43f5e;
            --text-heading: #f8fafc;
            --text-body: #cbd5e1;
            --text-muted: #64748b;
            --border-glow: #1e293b;
        }

        body { 
            font-family: 'Inter', system-ui, -apple-system, sans-serif; 
            background-color: var(--bg-main); 
            margin: 0; 
            display: flex; 
            color: var(--text-body); 
            letter-spacing: -0.01em;
        }

        .sidebar { 
            width: 280px; 
            background-color: var(--panel-bg); 
            height: 100vh; 
            padding: 30px 24px; 
            box-sizing: border-box; 
            border-right: 1px solid var(--border-glow); 
            position: fixed; 
        }

        .sidebar h1 { 
            font-size: 1.6rem;
            font-weight: 800;
            background: linear-gradient(to right, var(--primary-glow), var(--secondary-glow));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin: 0 0 5px 0; 
        }

        .sidebar p { color: var(--text-muted); margin: 5px 0 25px 0; font-size: 14px; font-weight: 500; }
        
        /* --- Sidebar Navigation Links --- */
        .sidebar a { 
            display: block; 
            color: #94a3b8; 
            text-decoration: none; 
            padding: 14px 20px; 
            font-weight: 600; 
            font-size: 15px;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid rgba(255, 255, 255, 0.04);
            margin-bottom: 12px;
            box-sizing: border-box;
            transition: all 0.2s ease;
        }
        
        .sidebar a:hover { 
            color: white; 
            background: rgba(168, 85, 247, 0.16);
            border-color: rgba(168, 85, 247, 0.4);
            box-shadow: 0 0 20px rgba(168, 85, 247, 0.4);
        }

        /* Override for Logout link */
        .sidebar a[href*="logout"] {
            color: var(--accent-rose);
            background: rgba(244, 63, 94, 0.03);
            border-color: rgba(244, 63, 94, 0.1);
            margin-top: 20px;
        }
        .sidebar a[href*="logout"]:hover {
            background: rgba(244, 63, 94, 0.15);
            border-color: rgba(244, 63, 94, 0.4);
            box-shadow: 0 0 20px rgba(244, 63, 94, 0.4);
            color: #ff4d6d;
        }

        .main-content { flex: 1; padding: 40px; margin-left: 280px; box-sizing: border-box; background-color: var(--bg-main); }
        
        .card { 
            background: var(--card-bg); 
            padding: 30px; 
            border-radius: 16px; 
            border: 1px solid var(--border-glow); 
            margin-bottom: 30px; 
            box-shadow: 0 20px 40px -15px rgba(0,0,0,0.5);
            position: relative;
            overflow: hidden;
        }

        .card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; height: 1px;
            background: linear-gradient(90deg, transparent, rgba(139, 92, 246, 0.2), transparent);
        }

        .card h3 { margin-top: 0; color: var(--text-heading); font-size: 1.25rem; font-weight: 700; margin-bottom: 20px; }
        
        .input-bid { 
            width: 100%; 
            padding: 14px; 
            background: rgba(6, 9, 19, 0.6); 
            border: 1px solid var(--border-glow); 
            border-radius: 8px; 
            color: white; 
            font-size: 16px; 
            box-sizing: border-box; 
            margin-bottom: 15px; 
            transition: border-color 0.2s;
        }
        .input-bid:focus { border-color: var(--primary-glow); outline: none; }

        /* --- Action Buttons (Main Panel) --- */
        .btn { 
            padding: 14px 24px; 
            border: none; 
            border-radius: 12px; 
            font-weight: 700; 
            cursor: pointer; 
            font-size: 15px; 
            width: 100%; 
            box-sizing: border-box;
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        }

        /* Deploy Request Button */
        .btn-success { 
            background: rgba(255, 255, 255, 0.02); 
            color: var(--text-heading); 
            border: 1px solid rgba(255, 255, 255, 0.04);
        }
        .btn-success:hover { 
            background: rgba(168, 85, 247, 0.16); 
            border-color: rgba(168, 85, 247, 0.4);
            color: white; 
            box-shadow: 0 0 20px rgba(168, 85, 247, 0.4);
        }

        /* Accept Bid Button */
        .btn-accept {
            background: rgba(56, 189, 248, 0.04);
            color: #38bdf8;
            border: 1px solid rgba(56, 189, 248, 0.15);
        }
        .btn-accept:hover {
            background: rgba(56, 189, 248, 0.2);
            border-color: rgba(56, 189, 248, 0.5);
            color: white;
            box-shadow: 0 0 20px rgba(56, 189, 248, 0.45);
        }

        /* Decline Bid Button */
        .btn-decline {
            background: rgba(244, 63, 94, 0.03);
            color: var(--accent-rose);
            border: 1px solid rgba(244, 63, 94, 0.1);
        }
        .btn-decline:hover {
            background: rgba(244, 63, 94, 0.15);
            border-color: rgba(244, 63, 94, 0.4);
            color: #ff4d6d;
            box-shadow: 0 0 20px rgba(244, 63, 94, 0.4);
        }

        .market-item { 
            background: rgba(255, 255, 255, 0.02); 
            padding: 24px; 
            border-radius: 12px; 
            margin-bottom: 20px; 
            border: 1px solid var(--border-glow); 
            transition: all 0.2s ease;
        }

        .table-header {
            display: grid;
            grid-template-columns: 1fr 2fr 2fr 1.5fr 1.2fr;
            padding: 12px 20px;
            color: var(--text-muted);
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .table-row {
            display: grid;
            grid-template-columns: 1fr 2fr 2fr 1.5fr 1.2fr;
            align-items: center;
            padding: 16px 20px;
            background: rgba(255, 255, 255, 0.01);
            border: 1px solid var(--border-glow);
            border-radius: 10px;
            margin-bottom: 8px;
        }

        .alert { 
            padding: 16px; 
            border-radius: 12px; 
            margin-bottom: 25px; 
            background: rgba(16, 185, 129, 0.1); 
            color: var(--accent-emerald); 
            border: 1px solid rgba(16, 185, 129, 0.2); 
            font-weight: 600;
        }
        
        .type-tag {
            font-size: 11px;
            background: rgba(139, 92, 246, 0.15);
            padding: 4px 10px;
            border-radius: 20px;
            border: 1px solid rgba(139, 92, 246, 0.3);
            color: #c084fc;
            font-weight: 600;
            display: inline-block;
        }

        .loading-container { display: flex; align-items: center; gap: 12px; color: var(--text-muted); font-size: 14px; font-weight: 500; margin-top: 10px; }
        .spinner { width: 20px; height: 20px; border: 3px solid var(--border-glow); border-top-color: var(--primary-glow); border-radius: 50%; animation: spin 0.8s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }
    </style>
</head>
<body>

<div class="sidebar">
    <h1>UniTransit</h1>
    <p>Passenger Hub Panel</p>
    
    <div style="background: rgba(255,255,255,0.03); border: 1px solid var(--border-glow); padding: 16px; border-radius: 12px; margin-bottom: 20px; text-align: center;">
        <% 
            Map<String, Object> meMap = (Map<String, Object>) request.getAttribute("me");
            String studentCardImg = (meMap != null) ? (String) meMap.get("photo") : null;
            if (studentCardImg != null && !studentCardImg.trim().isEmpty() && !studentCardImg.contains("default.png")) { 
        %>
            <img src="<%= studentCardImg %>" alt="Student Card" style="width: 80px; height: 80px; border-radius: 50%; object-fit: cover; margin: 0 auto 12px auto; display: block; border: 2px solid var(--primary-glow);" />
        <% } else { %>
            <div style="width: 80px; height: 80px; border-radius: 50%; background: rgba(255,255,255,0.04); margin: 0 auto 12px auto; display: flex; align-items: center; justify-content: center; border: 2px dashed var(--border-glow); color: var(--text-muted); font-size: 11px;">No Image</div>
        <% } %>
        <span style="color: var(--text-muted); display:block; font-size:10px; text-transform:uppercase; font-weight:700; text-align: left;">Passenger Account</span>
        <strong style="color: var(--text-heading); font-size: 15px; display: block; text-align: left; margin-top: 2px;"><%= session.getAttribute("username") %></strong>
    </div>
    
    <a href="main?action=profile">Edit Hub Profile</a>
    <a href="main?action=logout">Terminal Logout</a>
</div>

<div class="main-content">
    <% if(request.getParameter("msg") != null) { %>
        <div class="alert" id="systemAlertBox"><%= request.getParameter("msg") %></div>
    <% } else { %>
        <div class="alert" id="systemAlertBox" style="display:none;"></div>
    <% } %>

    <div class="card">
        <h3>Initialize Transit Stream Request</h3>
        <form id="requestForm" action="main" method="POST">
            <input type="hidden" name="action" value="createRequest" />
            <label style="display:block; margin-bottom:8px; font-size: 14px;">Pickup Location Vector</label>
            <input type="text" name="pickup" class="input-bid" placeholder="e.g. FSKTM Block A" required />
            <label style="display:block; margin-bottom:8px; font-size: 14px;">Drop-off Location Vector</label>
            <input type="text" name="dropoff" class="input-bid" placeholder="e.g. College Cafeteria" required />
            <label style="display:block; margin-bottom:8px; font-size: 14px;">Vehicle Archetype Preference</label>
            
            <select name="vehicle_type" class="input-bid" style="background: rgba(6, 9, 19, 0.85); color: #fff;">
                <option value="Standard Sedan Core (4 Seats)">Standard Sedan</option>
                <option value="Premium SUV">Premium SUV</option>
                <option value="Campus Motorbike">Campus Motorbike</option>
            </select>
            
            <div class="request-action-area">
                <button type="submit" class="btn btn-success">Deploy Transit Request</button>
            </div>
        </form>
    </div>

    <div class="card">
        <h3>Current Transit Status Streams</h3>
        <div id="dynamicJobContainer">
            <% 
                Map<String, Object> job = (Map<String, Object>) request.getAttribute("activeRequest");
                if (job == null) { 
            %>
                <p style="color: var(--text-muted); margin: 0; font-style: italic;">No active trip requests initialized in stream...</p>
            <% } else { 
                String status = (String) job.get("status");
            %>
                <div style="background: rgba(255,255,255,0.01); padding: 24px; border-radius: 12px; border: 1px solid var(--border-glow); border-left: 4px solid var(--accent-emerald);">
                    <p style="margin-top:0; font-size: 16px;"><strong>Route:</strong> <%= job.get("pickup") %> &rarr; <%= job.get("dropoff") %></p>
                    <p><strong>Status:</strong> <span style="color: #f59e0b; font-weight:bold; background: rgba(245,158,11,0.1); padding: 4px 10px; border-radius: 6px;"><%= status %></span></p>

                    <% if ("PENDING".equals(status) || "OFFERED".equals(status)) { %>
                        <div class="loading-container">
                            <div class="spinner"></div>
                            <span>Scanning environment for available driver bids...</span>
                        </div>
                    <% } %>

                    <% if ("ACCEPTED".equals(status)) { %>
                        <div class="loading-container" style="color: var(--accent-emerald);">
                            <span>✔ Driver is currently en-route to your destination matrix coordinates.</span>
                        </div>
                    <% } %>
                </div>
            <% } %>
        </div>
    </div>

    <div class="card">
        <h3>Inbound Driver Bid Offers</h3>
        <div id="dynamicMarketFeed">
            <% if (job != null && "OFFERED".equals(job.get("status"))) { 
                Object reqId = job.get("id") != null ? job.get("id") : job.get("request_id");
                Object fareVal = job.get("offer_price") != null ? job.get("offer_price") : (job.get("fare") != null ? job.get("fare") : "0.00");
                String driverName = job.get("driver_name") != null ? job.get("driver_name").toString() : "Field Driver";
            %>
                <div style="background: rgba(255, 255, 255, 0.02); padding: 20px; border-radius: 12px; border: 1px solid var(--border-glow); display: flex; align-items: center; justify-content: space-between;">
                    <div>
                        <strong style="color: #fff; font-size: 15px;"><%= driverName %></strong>
                        <div style="color: var(--text-muted); font-size: 13px; margin-top: 4px;">Proposed counter-fare price for current destination vector</div>
                    </div>
                    <div style="display: flex; align-items: center; gap: 20px;">
                        <span style="font-size: 18px; font-weight: 800; color: var(--accent-emerald);">RM <%= String.format("%.2f", Double.parseDouble(fareVal.toString())) %></span>
                        <div style="display: flex; gap: 8px;">
                            <form method="POST" style="margin:0;" onsubmit="handleBidAction(event, this)">
                                <input type="hidden" name="action" value="acceptBid" />
                                <input type="hidden" name="requestId" value="<%= reqId %>" />
                                <div class="bid-action-area" style="width: 100%;">
                                    <button type="submit" class="btn btn-accept">Accept</button>
                                </div>
                            </form>
                            <form method="POST" style="margin:0;" onsubmit="handleBidAction(event, this)">
                                <input type="hidden" name="action" value="rejectBid" />
                                <input type="hidden" name="requestId" value="<%= reqId %>" />
                                <button type="submit" class="btn btn-decline">Decline</button>
                            </form>
                        </div>
                    </div>
                </div>
            <% } else { %>
                <p style="color: var(--text-muted); margin: 0; font-style: italic;">Awaiting incoming price offers from field drivers...</p>
            <% } %>
        </div>
    </div>

    <div class="card">
        <h3>Archived Transit Ledger History</h3>
        <div id="driverHistoryTable">
            <div class="table-header">
                <div>Trip ID</div>
                <div>Pickup</div>
                <div>Dropoff</div>
                <div>Vehicle Archetype</div>
                <div>Fare Settled</div>
            </div>
            <div class="table-body">
                <% 
                    List<Map<String, Object>> history = (List<Map<String, Object>>) request.getAttribute("history");
                    if (history != null && !history.isEmpty()) {
                        for (Map<String, Object> h : history) {
                            String rawType = h.get("vehicle_type") != null ? h.get("vehicle_type").toString() : "Standard Sedan";
                            String cleanedType = rawType.contains("Standard Sedan") ? "Standard Sedan" : rawType;
                %>
                    <div class="table-row">
                        <div style="color: var(--primary-glow); font-weight: 700;">#<%= h.get("id") %></div>
                        <div><%= h.get("pickup") %></div>
                        <div><%= h.get("dropoff") %></div>
                        <div><span class="type-tag"><%= cleanedType %></span></div>
                        <div style="color: var(--accent-emerald); font-weight: 700;">RM <%= String.format("%.2f", h.get("fare")) %></div>
                    </div>
                <% 
                        }
                    } else { 
                %>
                    <div style="text-align: center; color: var(--text-muted); padding: 30px; font-style: italic;">No trip parameters logged to database ledger.</div>
                <% } %>
            </div>
        </div>
    </div>
</div>

<script>
    let currentlyHasActiveJob = <%= job != null %>;

    document.getElementById('requestForm').addEventListener('submit', function(e) {
        e.preventDefault(); 
        showRequestLoading(this);
        const searchParams = new URLSearchParams(new FormData(this));

        fetch('main', {
            method: 'POST',
            body: searchParams,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        })
        .then(() => {
            pollPassengerMatrix(true); 
            document.getElementsByName('pickup')[0].value = '';
            document.getElementsByName('dropoff')[0].value = '';
        });
    });

    function handleBidAction(event, formElement) {
        event.preventDefault();
        showBidLoading(formElement);
        
        const searchParams = new URLSearchParams(new FormData(formElement));
        fetch('main', {
            method: 'POST',
            body: searchParams,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        })
        .then(response => {
            if (response.redirected) {
                const url = new URL(response.url);
                const msg = url.searchParams.get("msg");
                if (msg) {
                    const alertBox = document.getElementById("systemAlertBox");
                    if (alertBox) {
                        alertBox.innerText = decodeURIComponent(msg.replace(/\+/g, ' '));
                        alertBox.style.display = "block";
                    }
                }
            }
            pollPassengerMatrix(true);
        })
        .catch(err => console.error("Error processing transaction choice:", err));
    }

    function showRequestLoading(formElement) {
        const actionArea = formElement.querySelector('.request-action-area');
        if(actionArea) actionArea.innerHTML = '<div class="loading-container"><div class="spinner"></div><span>Deploying parameters...</span></div>';
    }

    function showBidLoading(formElement) {
        const actionArea = formElement.querySelector('.bid-action-area');
        if(actionArea) actionArea.innerHTML = '<div class="loading-container"><div class="spinner"></div><span>Processing choice...</span></div>';
    }

    function pollPassengerMatrix(forceUpdate = false) {
        const requestForm = document.getElementById('requestForm');
        if (!forceUpdate && requestForm && requestForm.contains(document.activeElement)) return; 

        fetch('main?action=getDashboardData')
            .then(response => response.json())
            .then(data => {
                if (data.hasActiveRequest !== currentlyHasActiveJob) {
                    location.reload();
                    return;
                }

                const jobContainer = document.getElementById('dynamicJobContainer');
                const marketFeed = document.getElementById('dynamicMarketFeed');

                if (data.hasActiveRequest && jobContainer && marketFeed) {
                    const jobObj = data.request;
                    const reqId = jobObj.id || jobObj.request_id;
                    const fareVal = parseFloat(jobObj.offer_price || jobObj.fare || 0).toFixed(2);
                    const driverName = jobObj.driver_name || "Field Driver";

                    let jobHtml = `
                        <div style="background: rgba(255,255,255,0.01); padding: 24px; border-radius: 12px; border: 1px solid var(--border-glow); border-left: 4px solid var(--accent-emerald);">
                            <p style="margin-top:0; font-size: 16px;"><strong>Route:</strong> \${jobObj.pickup} &rarr; \${jobObj.dropoff}</p>
                            <p><strong>Status:</strong> <span style="color: #f59e0b; font-weight:bold; background: rgba(245,158,11,0.1); padding: 4px 10px; border-radius: 6px;">\${jobObj.status}</span></p>
                    `;

                    if (jobObj.status === 'PENDING' || jobObj.status === 'OFFERED') {
                        jobHtml += `
                            <div class="loading-container">
                                <div class="spinner"></div>
                                <span>Scanning environment for available driver bids...</span>
                            </div>
                        `;
                    } else if (jobObj.status === 'ACCEPTED') {
                        jobHtml += `
                            <div class="loading-container" style="color: var(--accent-emerald);">
                                <span>✔ Driver is currently en-route...</span>
                            </div>
                        `;
                    }
                    jobHtml += `</div>`;
                    jobContainer.innerHTML = jobHtml;

                    if (jobObj.status === 'OFFERED') {
                        marketFeed.innerHTML = `
                            <div style="background: rgba(255, 255, 255, 0.02); padding: 20px; border-radius: 12px; border: 1px solid var(--border-glow); display: flex; align-items: center; justify-content: space-between;">
                                <div>
                                    <strong style="color: #fff; font-size: 15px;">\${driverName}</strong>
                                    <div style="color: var(--text-muted); font-size: 13px; margin-top: 4px;">Proposed counter-fare price for current destination vector</div>
                                </div>
                                <div style="display: flex; align-items: center; gap: 20px;">
                                    <span style="font-size: 18px; font-weight: 800; color: var(--accent-emerald);">RM \${fareVal}</span>
                                    <div style="display: flex; gap: 8px;">
                                        <form method="POST" style="margin:0;" onsubmit="handleBidAction(event, this)">
                                            <input type="hidden" name="action" value="acceptBid" />
                                            <input type="hidden" name="requestId" value="\${reqId}" />
                                            <div class="bid-action-area" style="width: 100%;">
                                                <button type="submit" class="btn btn-accept">Accept</button>
                                            </div>
                                        </form>
                                        <form method="POST" style="margin:0;" onsubmit="handleBidAction(event, this)">
                                            <input type="hidden" name="action" value="rejectBid" />
                                            <input type="hidden" name="requestId" value="\${reqId}" />
                                            <button type="submit" class="btn btn-decline">Decline</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        `;
                    } else {
                        marketFeed.innerHTML = `<p style="color: var(--text-muted); margin: 0; font-style: italic;">Awaiting incoming price offers from field drivers...</p>`;
                    }
                }
            }).catch(err => console.error("Sync stream connection error."));
    }

    setInterval(pollPassengerMatrix, 3000);
</script>
</body>
</html>