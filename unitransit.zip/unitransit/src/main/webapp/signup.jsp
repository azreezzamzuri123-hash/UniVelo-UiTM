<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>UniTransit - Centralized Node Registration</title>
    <style>
        :root {
            --bg-color: #0f172a;
            --card-bg: #1e293b;
            --accent-blue: #38bdf8;
            --accent-green: #34d399;
            --text-main: #f8fafc;
            --text-muted: #94a3b8;
            --border-color: #334155;
        }

        body {
            background-color: var(--bg-color);
            color: var(--text-main);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .signup-container {
            background-color: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 40px;
            width: 100%;
            max-width: 500px;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.3);
            margin: 20px;
        }

        h2 {
            margin-top: 0;
            font-size: 28px;
            font-weight: 600;
            color: var(--text-main);
            text-align: center;
            letter-spacing: -0.5px;
        }

        p.subtitle {
            text-align: center;
            color: var(--text-muted);
            margin-top: -10px;
            margin-bottom: 30px;
            font-size: 14px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-size: 14px;
            font-weight: 500;
            color: var(--text-main);
        }

        input[type="text"],
        input[type="password"],
        input[type="tel"],
        select {
            width: 100%;
            padding: 12px;
            background-color: var(--bg-color);
            border: 1px solid var(--border-color);
            border-radius: 6px;
            color: var(--text-main);
            font-size: 15px;
            box-sizing: border-box;
            transition: border-color 0.2s;
        }

        input:focus, select:focus {
            outline: none;
            border-color: var(--accent-blue);
        }

        input[type="file"] {
            color: var(--text-muted);
            font-size: 14px;
            margin-top: 5px;
        }

        .dynamic-section {
            background-color: rgba(15, 23, 42, 0.4);
            border-radius: 8px;
            padding: 15px;
            border: 1px dashed var(--border-color);
            margin-top: 15px;
        }

        .btn-submit {
            width: 100%;
            padding: 14px;
            background-color: var(--accent-blue);
            color: #0f172a;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.2s, transform 0.1s;
            margin-top: 10px;
        }

        .btn-submit:hover {
            background-color: #7dd3fc;
        }

        .btn-submit:active {
            transform: scale(0.98);
        }

        .footer-links {
            text-align: center;
            margin-top: 25px;
            font-size: 14px;
            color: var(--text-muted);
        }

        .footer-links a {
            color: var(--accent-blue);
            text-decoration: none;
        }

        .footer-links a:hover {
            text-decoration: underline;
        }

        /* Error Alert Banner */
        .alert-danger {
            background-color: rgba(239, 68, 68, 0.15);
            color: #f87171;
            border: 1px solid rgba(239, 68, 68, 0.3);
            padding: 14px;
            border-radius: 6px;
            margin-bottom: 25px;
            font-size: 14px;
            line-height: 1.5;
        }
    </style>
    <script>
        function toggleRoleFields() {
            var role = document.getElementById("roleSelect").value;
            var passengerFields = document.getElementById("passengerFields");
            var driverFields = document.getElementById("driverFields");

            if (role === "PASSENGER") {
                passengerFields.style.display = "block";
                driverFields.style.display = "none";
                setRequired(passengerFields, true);
                setRequired(driverFields, false);
            } else if (role === "DRIVER") {
                passengerFields.style.display = "none";
                driverFields.style.display = "block";
                setRequired(passengerFields, false);
                setRequired(driverFields, true);
            } else {
                passengerFields.style.display = "none";
                driverFields.style.display = "none";
                setRequired(passengerFields, false);
                setRequired(driverFields, false);
            }
        }

        function setRequired(container, isRequired) {
            var inputs = container.querySelectorAll("input, select, textarea");
            inputs.forEach(function(input) {
                if (isRequired) {
                    input.setAttribute("required", "required");
                } else {
                    input.removeAttribute("required");
                }
            });
        }
    </script>
</head>
<body>

    <div class="signup-container">
        <h2>Create Account</h2>
        <p class="subtitle">Deploy your operational profile node into UniTransit</p>

        <%-- DUPLICATE ACCOUNT ERROR WARNING INTERCEPTOR --%>
        <% if (request.getParameter("error") != null && "duplicate".equals(request.getParameter("error"))) { %>
            <div class="alert-danger">
                <strong>Registration Halted:</strong> The username <strong>'<%= request.getParameter("user") %>'</strong> has already been allocated in our database records. Please try a different handle.
            </div>
        <% } %>

        <form action="main?action=signup" method="POST" enctype="multipart/form-data">
            
            <div class="form-group">
                <label for="roleSelect">Network Assignment Tier</label>
                <select id="roleSelect" name="role" onchange="toggleRoleFields()" required>
                    <option value="" disabled selected>Select network role...</option>
                    <option value="PASSENGER">Passenger (Campus Commuter)</option>
                    <option value="DRIVER">Driver (Transit Provider)</option>
                </select>
            </div>

            <div class="form-group">
                <label>System Username</label>
                <input type="text" name="username" placeholder="Choose unique identifier" required />
            </div>

            <div class="form-group">
                <label>Security Access Encryption Key (Password)</label>
                <input type="password" name="password" placeholder="••••••••" required />
            </div>

            <div class="form-group">
                <label>Comms Link (Phone Number)</label>
                <input type="tel" name="phone" placeholder="e.g. +60123456789" required />
            </div>

            <div id="passengerFields" class="dynamic-section" style="display:none;">
                <h3 style="margin-top:0; font-size:16px; color:var(--accent-blue);">Passenger Authorization Verification</h3>
                <div class="form-group" style="margin-bottom:0;">
                    <label>Digital Student Matric Card (Image Upload)</label>
                    <input type="file" name="studentCardFile" accept="image/*" />
                </div>
            </div>

            <div id="driverFields" class="dynamic-section" style="display:none;">
                <h3 style="margin-top:0; font-size:16px; color:var(--accent-green);">Driver Operations Verification</h3>
                
                <div class="form-group">
                    <label>Transit Operator License (Image Upload)</label>
                    <input type="file" name="licenseFile" accept="image/*" />
                </div>

                <div class="form-group">
                    <label>Vehicle Fleet Tier</label>
                    <select name="vehicleType">
                        <option value="Standard Sedan">Standard Sedan Core (4 Seats)</option>
                        <option value="Campus Motorbike">Motorcycle Node (1 Seat)</option>
                        <option value="Premium SUV">Premium Heavy SUV (6 Seats)</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Vehicle Identification Specification (Model/Color)</label>
                    <input type="text" name="modelInfo" placeholder="e.g. Perodua Myvi Black" />
                </div>

                <div class="form-group" style="margin-bottom:0;">
                    <label>Transit License Transponder Tag (Plate Number)</label>
                    <input type="text" name="plateNumber" placeholder="e.g. WA1234B" />
                </div>
            </div>

            <button type="submit" class="btn-submit">Register Profile Node</button>
        </form>

        <div class="footer-links">
            Already authenticated? <a href="login.jsp">Access Terminal Gate</a>
        </div>
    </div>

</body>
</html>